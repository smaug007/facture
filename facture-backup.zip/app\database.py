# -*- coding: utf-8 -*-
"""
Gestion de la base de données SQLite
"""

import sqlite3
import os
from datetime import datetime
from werkzeug.security import generate_password_hash
from app.config import Config

def get_db_connection():
    """Obtenir une connexion à la base de données"""
    conn = sqlite3.connect(Config.DATABASE_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    """Initialiser la base de données avec le schéma"""
    
    conn = get_db_connection()
    cursor = conn.cursor()
    
    # Table: users
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT NOT NULL UNIQUE,
            password_hash TEXT NOT NULL,
            full_name TEXT NOT NULL,
            role TEXT NOT NULL CHECK(role IN ('admin', 'data_entry')),
            is_active BOOLEAN DEFAULT 1,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ''')
    
    # Table: companies
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS companies (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            address TEXT NOT NULL,
            phone TEXT NOT NULL,
            niu TEXT NOT NULL,
            rc TEXT NOT NULL,
            email TEXT,
            is_active BOOLEAN DEFAULT 1,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ''')
    
    # Table: clients
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS clients (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            address TEXT NOT NULL,
            phone TEXT NOT NULL,
            niu TEXT NOT NULL,
            rc TEXT NOT NULL,
            email TEXT,
            is_active BOOLEAN DEFAULT 1,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            created_by INTEGER,
            FOREIGN KEY (created_by) REFERENCES users(id)
        )
    ''')
    
    # Table: services
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS services (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            designation TEXT NOT NULL UNIQUE,
            is_active BOOLEAN DEFAULT 1,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ''')
    
    # Table: invoices
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS invoices (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            invoice_number TEXT NOT NULL UNIQUE,
            company_id INTEGER NOT NULL,
            client_id INTEGER NOT NULL,
            invoice_date DATE NOT NULL,
            reference TEXT,
            additional_info TEXT,
            total_amount REAL DEFAULT 0,
            is_deleted BOOLEAN DEFAULT 0,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            created_by INTEGER NOT NULL,
            deleted_by INTEGER,
            deleted_at TIMESTAMP,
            FOREIGN KEY (company_id) REFERENCES companies(id),
            FOREIGN KEY (client_id) REFERENCES clients(id),
            FOREIGN KEY (created_by) REFERENCES users(id),
            FOREIGN KEY (deleted_by) REFERENCES users(id)
        )
    ''')
    
    # Table: invoice_items
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS invoice_items (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            invoice_id INTEGER NOT NULL,
            service_id INTEGER NOT NULL,
            designation TEXT NOT NULL,
            amount REAL NOT NULL,
            item_order INTEGER DEFAULT 0,
            FOREIGN KEY (invoice_id) REFERENCES invoices(id) ON DELETE CASCADE,
            FOREIGN KEY (service_id) REFERENCES services(id)
        )
    ''')
    
    # Table: client_templates
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS client_templates (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            client_id INTEGER NOT NULL,
            template_name TEXT NOT NULL,
            is_default BOOLEAN DEFAULT 0,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (client_id) REFERENCES clients(id) ON DELETE CASCADE
        )
    ''')
    
    # Table: template_items
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS template_items (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            template_id INTEGER NOT NULL,
            service_id INTEGER NOT NULL,
            item_order INTEGER DEFAULT 0,
            FOREIGN KEY (template_id) REFERENCES client_templates(id) ON DELETE CASCADE,
            FOREIGN KEY (service_id) REFERENCES services(id)
        )
    ''')
    
    # Table: settings
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS settings (
            key TEXT PRIMARY KEY,
            value TEXT NOT NULL,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ''')
    
    # Table: audit_log
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS audit_log (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            action TEXT NOT NULL,
            entity_type TEXT NOT NULL,
            entity_id INTEGER,
            details TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users(id)
        )
    ''')
    
    # Index pour performance
    cursor.execute('CREATE INDEX IF NOT EXISTS idx_invoices_client ON invoices(client_id)')
    cursor.execute('CREATE INDEX IF NOT EXISTS idx_invoices_date ON invoices(invoice_date)')
    cursor.execute('CREATE INDEX IF NOT EXISTS idx_invoices_number ON invoices(invoice_number)')
    cursor.execute('CREATE INDEX IF NOT EXISTS idx_invoice_items_invoice ON invoice_items(invoice_id)')
    cursor.execute('CREATE INDEX IF NOT EXISTS idx_audit_log_user ON audit_log(user_id)')
    cursor.execute('CREATE INDEX IF NOT EXISTS idx_audit_log_entity ON audit_log(entity_type, entity_id)')
    
    conn.commit()
    conn.close()
    
    # Initialiser les paramètres par défaut
    init_default_settings()
    # Initialiser les services par défaut
    init_default_services()

def create_default_admin():
    """Créer un compte admin par défaut si aucun utilisateur n'existe"""
    
    conn = get_db_connection()
    cursor = conn.cursor()
    
    # Vérifier si des utilisateurs existent
    cursor.execute('SELECT COUNT(*) as count FROM users')
    count = cursor.fetchone()['count']
    
    if count == 0:
        # Créer l'administrateur par défaut
        password_hash = generate_password_hash('admin123')
        cursor.execute('''
            INSERT INTO users (username, password_hash, full_name, role)
            VALUES (?, ?, ?, ?)
        ''', ('admin', password_hash, 'Administrateur', 'admin'))
        conn.commit()
        print("✅ Administrateur par défaut créé (username: admin, password: admin123)")
    
    conn.close()

def init_default_settings():
    """Initialiser les paramètres système par défaut"""
    
    conn = get_db_connection()
    cursor = conn.cursor()
    
    # Vérifier si les paramètres existent
    cursor.execute('SELECT COUNT(*) as count FROM settings')
    count = cursor.fetchone()['count']
    
    if count == 0:
        current_year = datetime.now().year
        settings = [
            ('fiscal_year', str(current_year)),
            ('invoice_start_number', '1'),
            ('date_format', 'DD/MM/YYYY'),
            ('language', 'fr'),
            ('pdf_save_path', Config.PDF_EXPORT_FOLDER),
            ('excel_save_path', Config.EXCEL_EXPORT_FOLDER),
        ]
        
        cursor.executemany('INSERT INTO settings (key, value) VALUES (?, ?)', settings)
        conn.commit()
        print("✅ Paramètres par défaut initialisés")
    
    conn.close()

def init_default_services():
    """Initialiser les services fréquemment utilisés"""
    
    conn = get_db_connection()
    cursor = conn.cursor()
    
    # Vérifier si des services existent
    cursor.execute('SELECT COUNT(*) as count FROM services')
    count = cursor.fetchone()['count']
    
    if count == 0:
        services = [
            'Frais de dossier',
            'Frais fixe de dossier',
            'Assurance',
            'Fiche Guichet Unique',
            'Redevance PAK',
            'Redevance PAD',
            'Frais de mise à disposition conteneur',
            'Kribi Port Inspection',
            'Sortie conteneur',
            'Vacation Douane',
            'Acconage KCT',
            'Acconage RTC',
            'Frais Pesée',
            'Transport pour Livraison Kribi-Douala-Kribi',
            'Transport pour Livraison',
            'TEL informatique et deblocage ASIE',
            'TEL sortie',
            'TEL Informatique',
            'TEL Douane',
            'TEL Informatique et Facilitation',
            'Frais APM',
            'Factures MAERSK',
            'Factures MSC',
            'Factures CMA',
            'Droits de douane ESTIMATIFS',
            'Frais Bancaire',
            'Frais de banque',
            'Authentification lettre d\'Exo',
            'Frais Procuration',
            'Frais de visite et caution',
            'Timbre sur BL',
            'Manipulation',
            'Manutention-Manipulation',
            'Remise documentaire ADC',
            'Remise documentaire DHL',
            'BESC',
            'Phytosanitaire',
            'Declaration d\'importation',
            'Certificat de contrôle Sanitaire',
            'Frais telex release',
            'Frais release',
            'Frais d\'Estempillage',
            'Surestaries',
            'Stationnement',
            'Encombrement et stationement',
            'Detention TC',
            'Retour Vide',
            'Frais de retour vide',
            'Container clean CMA',
            'Container MEDLOG',
            'Annulation annuelle Precompte',
            'Inscription au fichier des Exportateurs',
        ]
        
        for service in services:
            try:
                cursor.execute('INSERT INTO services (designation) VALUES (?)', (service,))
            except sqlite3.IntegrityError:
                # Le service existe déjà
                pass
        
        conn.commit()
        print(f"✅ {len(services)} services par défaut initialisés")
    
    conn.close()

def log_action(user_id, action, entity_type, entity_id=None, details=None):
    """Enregistrer une action dans le journal d'audit"""
    
    conn = get_db_connection()
    cursor = conn.cursor()
    
    cursor.execute('''
        INSERT INTO audit_log (user_id, action, entity_type, entity_id, details)
        VALUES (?, ?, ?, ?, ?)
    ''', (user_id, action, entity_type, entity_id, details))
    
    conn.commit()
    conn.close()

