# -*- coding: utf-8 -*-
"""
Routes de l'application
"""

