# -*- coding: utf-8 -*-
"""
Fonctions de validation
"""

import re

def validate_email(email):
    """Valider une adresse email"""
    if not email:
        return True  # Email optionnel
    
    pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
    return re.match(pattern, email) is not None

def validate_phone(phone):
    """Valider un numéro de téléphone"""
    if not phone:
        return False
    
    # Accepter différents formats de téléphone camerounais
    pattern = r'^\+?237?[\s-]?[6][0-9]{8}$|^[6][0-9]{8}$|^\([0-9]{3}\)\s?[0-9]{3}\s?[0-9]{3}\s?[0-9]{3}$'
    return re.match(pattern, phone.replace(' ', '').replace('-', '')) is not None or len(phone) >= 9

def validate_niu(niu):
    """Valider un NIU (Numéro d'Identification Unique)"""
    if not niu:
        return False
    
    # Format: M101914203431F ou similaire
    return len(niu) >= 5

def validate_rc(rc):
    """Valider un RC (Registre de Commerce)"""
    if not rc:
        return False
    
    # Format: RC/06/B/380 ou similaire
    return len(rc) >= 5

def validate_invoice_number(invoice_number):
    """Valider un numéro de facture"""
    if not invoice_number:
        return False
    
    # Format: 001/11/2025
    pattern = r'^\d{3}/\d{2}/\d{4}$'
    return re.match(pattern, invoice_number) is not None

def validate_amount(amount):
    """Valider un montant"""
    try:
        value = float(amount)
        return value >= 0
    except (ValueError, TypeError):
        return False

def sanitize_string(text):
    """Nettoyer une chaîne de caractères"""
    if not text:
        return ''
    
    return text.strip()

