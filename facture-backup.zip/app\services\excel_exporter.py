# -*- coding: utf-8 -*-
"""
Export de factures en Excel
"""

import os
from openpyxl import Workbook
from openpyxl.styles import Font, Alignment, Border, Side, PatternFill
from datetime import datetime
from app.utils.helpers import format_amount, format_date, format_date_french
from app.config import Config

def export_invoice_to_excel(invoice_data, output_path=None):
    """
    Exporter une facture vers Excel
    
    Args:
        invoice_data: Dictionnaire contenant toutes les données de la facture
        output_path: Chemin de sortie (optionnel)
    
    Returns:
        str: Chemin du fichier Excel généré
    """
    
    # Générer le nom de fichier si non fourni
    if not output_path:
        filename = f"Facture_{invoice_data['invoice_number'].replace('/', '_')}.xlsx"
        output_path = os.path.join(Config.EXCEL_EXPORT_FOLDER, filename)
    
    # Créer le workbook
    wb = Workbook()
    ws = wb.active
    ws.title = "Facture"
    
    # Styles
    bold_font = Font(bold=True, size=12)
    title_font = Font(bold=True, size=14)
    header_fill = PatternFill(start_color="CCCCCC", end_color="CCCCCC", fill_type="solid")
    border = Border(
        left=Side(style='thin'),
        right=Side(style='thin'),
        top=Side(style='thin'),
        bottom=Side(style='thin')
    )
    center_align = Alignment(horizontal='center', vertical='center')
    
    row = 1
    
    # Date et lieu
    ws[f'C{row}'] = f"Douala, le {format_date_french(invoice_data['invoice_date'])}"
    ws[f'C{row}'].alignment = Alignment(horizontal='right')
    row += 2
    
    # Entreprise émettrice
    ws[f'C{row}'] = invoice_data['company_name'].upper()
    ws[f'C{row}'].font = title_font
    ws[f'C{row}'].alignment = center_align
    row += 1
    
    ws[f'C{row}'] = invoice_data['company_address']
    ws[f'C{row}'].alignment = center_align
    row += 1
    
    ws[f'C{row}'] = f"Tel : {invoice_data['company_phone']}"
    ws[f'C{row}'].alignment = center_align
    row += 1
    
    ws[f'C{row}'] = f"NIU : {invoice_data['company_niu']}"
    ws[f'C{row}'].alignment = center_align
    row += 1
    
    ws[f'C{row}'] = f"RC : {invoice_data['company_rc']}"
    ws[f'C{row}'].alignment = center_align
    row += 2
    
    # Numéro de facture
    ws[f'A{row}'] = f"Facture N° {invoice_data['invoice_number']}"
    ws[f'A{row}'].font = bold_font
    row += 2
    
    # Références
    if invoice_data.get('reference'):
        ws[f'A{row}'] = f"Références: {invoice_data['reference']}"
        row += 1
    
    if invoice_data.get('additional_info'):
        ws[f'A{row}'] = invoice_data['additional_info']
        row += 1
    
    row += 1
    
    # En-tête du tableau
    ws[f'A{row}'] = "Désignation"
    ws[f'A{row}'].font = bold_font
    ws[f'A{row}'].fill = header_fill
    ws[f'A{row}'].border = border
    ws[f'A{row}'].alignment = center_align
    
    ws[f'C{row}'] = "Montant"
    ws[f'C{row}'].font = bold_font
    ws[f'C{row}'].fill = header_fill
    ws[f'C{row}'].border = border
    ws[f'C{row}'].alignment = center_align
    
    row += 1
    
    # Articles
    for item in invoice_data['items']:
        ws[f'A{row}'] = item['designation']
        ws[f'A{row}'].border = border
        
        ws[f'C{row}'] = format_amount(item['amount'])
        ws[f'C{row}'].border = border
        ws[f'C{row}'].alignment = Alignment(horizontal='right')
        
        row += 1
    
    # NET A PAYER
    ws[f'A{row}'] = "NET A PAYER"
    ws[f'A{row}'].font = bold_font
    ws[f'A{row}'].fill = header_fill
    ws[f'A{row}'].border = border
    
    ws[f'C{row}'] = format_amount(invoice_data['total_amount'])
    ws[f'C{row}'].font = bold_font
    ws[f'C{row}'].fill = header_fill
    ws[f'C{row}'].border = border
    ws[f'C{row}'].alignment = Alignment(horizontal='right')
    
    row += 2
    
    # Montant en lettres
    from app.services.amount_converter import amount_to_french_words
    ws[f'A{row}'] = "Arrêté la présente facture à la somme de FCFA :"
    row += 1
    
    ws[f'A{row}'] = amount_to_french_words(invoice_data['total_amount'])
    ws[f'A{row}'].font = bold_font
    
    # Ajuster les largeurs de colonnes
    ws.column_dimensions['A'].width = 60
    ws.column_dimensions['B'].width = 5
    ws.column_dimensions['C'].width = 20
    
    # Sauvegarder
    wb.save(output_path)
    
    return output_path

def export_invoices_list_to_excel(invoices, output_path=None):
    """
    Exporter une liste de factures vers Excel
    
    Args:
        invoices: Liste de factures
        output_path: Chemin de sortie (optionnel)
    
    Returns:
        str: Chemin du fichier Excel généré
    """
    
    # Générer le nom de fichier si non fourni
    if not output_path:
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        filename = f"Liste_Factures_{timestamp}.xlsx"
        output_path = os.path.join(Config.EXCEL_EXPORT_FOLDER, filename)
    
    # Créer le workbook
    wb = Workbook()
    ws = wb.active
    ws.title = "Factures"
    
    # Styles
    bold_font = Font(bold=True)
    header_fill = PatternFill(start_color="4472C4", end_color="4472C4", fill_type="solid")
    header_font = Font(bold=True, color="FFFFFF")
    border = Border(
        left=Side(style='thin'),
        right=Side(style='thin'),
        top=Side(style='thin'),
        bottom=Side(style='thin')
    )
    
    # En-têtes
    headers = ['N° Facture', 'Date', 'Client', 'Entreprise', 'Montant (FCFA)', 'Date Création']
    for col, header in enumerate(headers, start=1):
        cell = ws.cell(row=1, column=col, value=header)
        cell.font = header_font
        cell.fill = header_fill
        cell.border = border
        cell.alignment = Alignment(horizontal='center', vertical='center')
    
    # Données
    for row_idx, invoice in enumerate(invoices, start=2):
        ws.cell(row=row_idx, column=1, value=invoice['invoice_number']).border = border
        ws.cell(row=row_idx, column=2, value=format_date(invoice['invoice_date'])).border = border
        ws.cell(row=row_idx, column=3, value=invoice.get('client_name', '')).border = border
        ws.cell(row=row_idx, column=4, value=invoice.get('company_name', '')).border = border
        
        amount_cell = ws.cell(row=row_idx, column=5, value=format_amount(invoice['total_amount']))
        amount_cell.border = border
        amount_cell.alignment = Alignment(horizontal='right')
        
        ws.cell(row=row_idx, column=6, value=format_date(invoice['created_at'])).border = border
    
    # Ajuster les largeurs
    ws.column_dimensions['A'].width = 20
    ws.column_dimensions['B'].width = 15
    ws.column_dimensions['C'].width = 30
    ws.column_dimensions['D'].width = 30
    ws.column_dimensions['E'].width = 20
    ws.column_dimensions['F'].width = 18
    
    # Sauvegarder
    wb.save(output_path)
    
    return output_path

