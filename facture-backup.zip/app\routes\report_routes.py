# -*- coding: utf-8 -*-
"""
Routes pour les rapports (Phase 2)
"""

from flask import Blueprint, jsonify, request
from app.database import get_db_connection
from app.utils.decorators import api_login_required

bp = Blueprint('reports', __name__, url_prefix='/api/reports')

@bp.route('/dashboard', methods=['GET'])
@api_login_required
def dashboard_stats():
    """Statistiques pour le dashboard"""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    # Factures ce mois
    cursor.execute('''
        SELECT COUNT(*) as count, COALESCE(SUM(total_amount), 0) as total
        FROM invoices
        WHERE strftime('%Y-%m', invoice_date) = strftime('%Y-%m', 'now')
        AND is_deleted = 0
    ''')
    
    month_stats = dict(cursor.fetchone())
    
    # Nombre de clients actifs
    cursor.execute('SELECT COUNT(*) as count FROM clients WHERE is_active = 1')
    clients_count = cursor.fetchone()['count']
    
    # Dernières factures
    cursor.execute('''
        SELECT 
            i.id, i.invoice_number, i.invoice_date, i.total_amount,
            c.name as client_name
        FROM invoices i
        JOIN clients c ON i.client_id = c.id
        WHERE i.is_deleted = 0
        ORDER BY i.created_at DESC
        LIMIT 5
    ''')
    
    recent_invoices = cursor.fetchall()
    conn.close()
    
    return jsonify({
        'success': True,
        'month_invoices_count': month_stats['count'],
        'month_total': month_stats['total'],
        'active_clients': clients_count,
        'recent_invoices': [dict(inv) for inv in recent_invoices]
    })

@bp.route('/by-client', methods=['GET'])
@api_login_required
def report_by_client():
    """Rapport par client (Phase 2)"""
    start_date = request.args.get('start_date')
    end_date = request.args.get('end_date')
    
    conn = get_db_connection()
    cursor = conn.cursor()
    
    query = '''
        SELECT 
            c.id, c.name,
            COUNT(i.id) as invoice_count,
            COALESCE(SUM(i.total_amount), 0) as total_amount
        FROM clients c
        LEFT JOIN invoices i ON c.id = i.client_id AND i.is_deleted = 0
    '''
    
    params = []
    
    if start_date and end_date:
        query += ' WHERE i.invoice_date BETWEEN ? AND ?'
        params.extend([start_date, end_date])
    
    query += ' GROUP BY c.id, c.name ORDER BY total_amount DESC'
    
    cursor.execute(query, params)
    results = cursor.fetchall()
    conn.close()
    
    return jsonify({'success': True, 'data': [dict(r) for r in results]})

