# Guide de Démarrage Rapide - AKTIVCO Facturation

## 🚀 Démarrage Immédiat

### Étape 1: Installer les dépendances

```bash
pip install -r requirements.txt
```

### Étape 2: Lancer l'application

```bash
python main.py
```

### Étape 3: Se connecter

- **Utilisateur:** `admin`
- **Mot de passe:** `admin123`

---

## ✅ Vérification de l'Installation

Si tout fonctionne correctement, vous devriez voir:

1. Une fenêtre de l'application s'ouvre automatiquement
2. La page de connexion s'affiche
3. Après connexion, le tableau de bord apparaît

---

## 🎯 Premiers Pas

### 1. Créer une Entreprise Émettrice

1. Cliquer sur **Entreprises** dans le menu
2. Cliquer sur **+ Nouvelle Entreprise**
3. Remplir tous les champs:
   - Nom: AKTIVCO CAMEROUN
   - Adresse: Bpriso-à côté du cub snec
   - Téléphone: (237) 696 279 801
   - NIU: M101914203431F
   - RC: RC/06/B/380
4. Cliquer sur **Enregistrer**

### 2. Créer un Client

1. Cliquer sur **Clients** dans le menu
2. Cliquer sur **+ Nouveau Client**
3. Remplir les informations du client
4. Cliquer sur **Enregistrer**

### 3. Créer votre Première Facture

1. Cliquer sur **+ Nouvelle Facture** sur le dashboard
2. Sélectionner l'entreprise émettrice
3. Sélectionner le client
4. Choisir la date
5. Ajouter des articles:
   - Rechercher dans le catalogue ou taper le nom
   - Entrer le montant
   - Cliquer sur **Ajouter**
6. Ajouter des références si nécessaire
7. Cliquer sur **Enregistrer**
8. Cliquer sur **Générer PDF**

---

## 📁 Structure des Fichiers

Après le premier lancement, vous verrez:

```
facture/
├── factures.db          # Base de données (créé automatiquement)
├── flask_session/       # Sessions (créé automatiquement)
└── exports/
    ├── pdf/            # Factures PDF générées
    └── excel/          # Exports Excel
```

---

## 🔐 Gestion des Utilisateurs

### Ajouter un Utilisateur (Admin uniquement)

1. Menu utilisateur (en haut à droite) → **Utilisateurs**
2. Cliquer sur **+ Nouvel Utilisateur**
3. Remplir:
   - Nom d'utilisateur
   - Mot de passe (min 6 caractères)
   - Nom complet
   - Rôle (Admin ou Saisie)
4. Cliquer sur **Créer**

### Changer le Mot de Passe

1. Menu utilisateur → **Mon Profil**
2. Entrer le nouveau mot de passe
3. Cliquer sur **Modifier**

---

## 📊 Utilisation Quotidienne

### Workflow Typique

1. **Matin:** Se connecter
2. **Créer factures** au fur et à mesure des demandes
3. **Générer PDF** et envoyer aux clients
4. **Consulter** les factures existantes si besoin
5. **Fin de journée:** Se déconnecter

### Conseils

- ✅ Les factures sont sauvegardées immédiatement
- ✅ Vous pouvez modifier une facture à tout moment
- ✅ Les numéros de facture sont générés automatiquement
- ✅ Les PDFs sont sauvegardés dans `exports/pdf/`
- ✅ Faites des copies de `factures.db` régulièrement (backup)

---

## 🐛 Problèmes Courants

### L'application ne s'ouvre pas

**Solution:** Vérifier que vous avez bien installé toutes les dépendances:
```bash
pip install -r requirements.txt
```

### "Port 5000 already in use"

**Solution:** Un autre programme utilise le port 5000. Fermer les autres applications ou redémarrer l'ordinateur.

### Impossible de se connecter

**Solution:** Utiliser les identifiants par défaut:
- Username: `admin`
- Password: `admin123`

### La base de données est corrompue

**Solution (⚠️ perte de données):**
1. Fermer l'application
2. Supprimer le fichier `factures.db`
3. Relancer l'application (nouvelle base créée)

---

## 📞 Support

Si vous rencontrez un problème:

1. Vérifier ce guide
2. Consulter `README.md`
3. Consulter `IMPLEMENTATION_PLAN.md`
4. Vérifier les fichiers de log

---

## 🎓 Formation Rapide

### Pour un Nouvel Utilisateur

**Temps estimé:** 15 minutes

1. **Connexion** (2 min)
   - Ouvrir l'application
   - Se connecter avec ses identifiants

2. **Tour du Dashboard** (3 min)
   - Comprendre les statistiques
   - Voir les actions rapides
   - Consulter les dernières factures

3. **Créer une Facture** (10 min)
   - Sélectionner entreprise et client
   - Ajouter des articles
   - Générer le PDF
   - Vérifier le résultat

**Après ces 15 minutes, l'utilisateur peut travailler de manière autonome!**

---

## 🚀 Prochaines Étapes

Une fois à l'aise avec les bases:

1. Explorer les **filtres et recherche** dans la liste des factures
2. Utiliser l'**export Excel** pour partager avec collègues
3. Consulter l'**historique client** pour voir toutes leurs factures
4. Créer des **templates clients** (Phase 2 - à venir)

---

**Bon travail! 🎉**

Si vous avez suivi ce guide, vous êtes prêt à utiliser AKTIVCO Facturation de manière productive!

