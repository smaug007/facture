# Instructions pour Uploader le Projet sur GitHub

## SOLUTION 1: GitHub Desktop (RECOMMANDÉE - TRÈS SIMPLE)

### Étape 1: Télécharger GitHub Desktop
1. Ouvrez votre navigateur
2. Allez sur: https://desktop.github.com/
3. Cliquez sur "Download for Windows"
4. Attendez le téléchargement (environ 100 MB)
5. Double-cliquez sur le fichier téléchargé
6. Suivez l'installation (cliquez "Next" partout)

### Étape 2: Se connecter à GitHub
1. Ouvrez GitHub Desktop
2. Cliquez "Sign in to GitHub.com"
3. Entrez vos identifiants GitHub
4. Cliquez "Sign in"

### Étape 3: Ajouter le projet
1. Dans GitHub Desktop, cliquez "File" → "Add local repository"
2. Cliquez "Choose..." et sélectionnez: D:\Apprenti\facture
3. GitHub Desktop dira "This directory does not appear to be a Git repository"
4. Cliquez "create a repository"
5. Nom: facture
6. Cliquez "Create Repository"

### Étape 4: Publier sur GitHub
1. En haut à droite, cliquez "Publish repository"
2. Décochez "Keep this code private" (pour repo public)
   OU laissez coché si vous voulez un repo privé
3. Cliquez "Publish repository"
4. Attendez quelques secondes - TERMINÉ ! ✅

---

## SOLUTION 2: Git en Ligne de Commande

### Étape 1: Installer Git
1. Téléchargez depuis: https://git-scm.com/download/win
2. Lancez l'installateur
3. Cliquez "Next" partout (laissez les options par défaut)
4. Cliquez "Install"
5. Fermez et rouvrez PowerShell

### Étape 2: Configurer Git
```powershell
git config --global user.name "smaug007"
git config --global user.email "tefack007@gmail.com"
```

### Étape 3: Initialiser et Pousser
```powershell
cd D:\Apprenti\facture

# Initialiser le repo
git init

# Ajouter tous les fichiers
git add .

# Commit
git commit -m "Initial commit - AKTIVCO Facturation MVP"

# Ajouter le remote
git remote add origin https://github.com/smaug007/facture.git

# Pousser vers GitHub
git push -u origin master
```

Quand demandé, entrez vos identifiants GitHub.

---

## SOLUTION 3: Upload Manuel (SI TOUT ÉCHOUE)

### Étape 1: Créer une archive
1. Clic droit sur le dossier D:\Apprenti\facture
2. Envoyer vers → Dossier compressé
3. Nommez: facture.zip

### Étape 2: Upload sur GitHub
1. Allez sur: https://github.com/smaug007/facture
2. Cliquez "uploading an existing file"
3. Glissez-déposez facture.zip
4. Cliquez "Commit changes"

---

## SUR L'AUTRE ORDINATEUR (avec Python installé)

### Télécharger le projet
```bash
git clone https://github.com/smaug007/facture.git
cd facture
pip install -r requirements.txt
python main.py
```

OU téléchargez le ZIP depuis GitHub et extrayez-le.

---

## QUELLE SOLUTION CHOISIR ?

- **GitHub Desktop** → Le plus simple, interface graphique
- **Git CLI** → Si vous aimez la ligne de commande
- **Upload Manuel** → Dernier recours si les deux autres échouent

---

Je recommande **GitHub Desktop** - c'est de loin le plus facile !

