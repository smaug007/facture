const XLSX = require('xlsx');
const fs = require('fs');

// Read the Excel file
const workbook = XLSX.readFile('FACTURES 2025A OK.xlsx');

// Get sheet names
console.log('=== SHEET NAMES ===');
console.log(workbook.SheetNames);
console.log('\n');

// Analyze each sheet
workbook.SheetNames.forEach((sheetName, index) => {
    console.log(`\n${'='.repeat(60)}`);
    console.log(`SHEET ${index + 1}: ${sheetName}`);
    console.log('='.repeat(60));
    
    const worksheet = workbook.Sheets[sheetName];
    
    // Convert to JSON to see structure
    const jsonData = XLSX.utils.sheet_to_json(worksheet, { header: 1, defval: '' });
    
    console.log(`\nTotal rows: ${jsonData.length}`);
    
    // Show first 20 rows to understand structure
    console.log('\n--- First 20 rows ---');
    jsonData.slice(0, 20).forEach((row, idx) => {
        console.log(`Row ${idx + 1}:`, JSON.stringify(row));
    });
    
    // If there are more rows, show a sample from middle
    if (jsonData.length > 40) {
        console.log('\n--- Sample from middle (rows 21-40) ---');
        jsonData.slice(20, 40).forEach((row, idx) => {
            console.log(`Row ${idx + 21}:`, JSON.stringify(row));
        });
    }
    
    // Show last 10 rows
    if (jsonData.length > 30) {
        console.log('\n--- Last 10 rows ---');
        jsonData.slice(-10).forEach((row, idx) => {
            console.log(`Row ${jsonData.length - 10 + idx + 1}:`, JSON.stringify(row));
        });
    }
    
    // Try to detect headers and patterns
    console.log('\n--- Data Analysis ---');
    if (jsonData.length > 0) {
        // Look for potential headers (rows with text in most columns)
        const potentialHeaders = jsonData.slice(0, 10).map((row, idx) => {
            const nonEmpty = row.filter(cell => cell !== '').length;
            return { rowIndex: idx + 1, nonEmptyCount: nonEmpty, data: row };
        }).filter(r => r.nonEmptyCount > 2);
        
        console.log('Potential header rows:');
        potentialHeaders.forEach(h => {
            console.log(`  Row ${h.rowIndex}: ${h.nonEmptyCount} non-empty cells - ${JSON.stringify(h.data)}`);
        });
    }
});

// Save detailed output to file
console.log('\n\n=== Saving detailed analysis to analysis-output.txt ===');

