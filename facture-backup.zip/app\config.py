# -*- coding: utf-8 -*-
"""
Configuration de l'application
"""

import os
from datetime import timedelta

class Config:
    """Configuration de l'application Flask"""
    
    # Clé secrète pour les sessions (à changer en production)
    SECRET_KEY = os.environ.get('SECRET_KEY') or 'dev-secret-key-change-in-production'
    
    # Base de données
    DATABASE_PATH = os.path.join(os.getcwd(), 'factures.db')
    
    # Session
    SESSION_TYPE = 'filesystem'
    SESSION_PERMANENT = True
    PERMANENT_SESSION_LIFETIME = timedelta(hours=12)
    SESSION_FILE_DIR = os.path.join(os.getcwd(), 'flask_session')
    
    # Upload et exports
    PDF_EXPORT_FOLDER = os.path.join(os.getcwd(), 'exports', 'pdf')
    EXCEL_EXPORT_FOLDER = os.path.join(os.getcwd(), 'exports', 'excel')
    
    # Créer les dossiers s'ils n'existent pas
    os.makedirs(SESSION_FILE_DIR, exist_ok=True)
    os.makedirs(PDF_EXPORT_FOLDER, exist_ok=True)
    os.makedirs(EXCEL_EXPORT_FOLDER, exist_ok=True)
    
    # Paramètres régionaux
    LANGUAGE = 'fr'
    TIMEZONE = 'Africa/Douala'
    CURRENCY = 'FCFA'
    
    # Format de date
    DATE_FORMAT = '%d/%m/%Y'
    DATETIME_FORMAT = '%d/%m/%Y %H:%M'

