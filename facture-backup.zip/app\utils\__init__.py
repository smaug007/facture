# -*- coding: utf-8 -*-
"""
Utilitaires de l'application
"""

