# -*- coding: utf-8 -*-
"""
Routes pour la gestion des factures
"""

from flask import Blueprint, jsonify, request, session
from datetime import datetime
from app.database import get_db_connection, log_action
from app.utils.decorators import api_login_required, admin_required
from app.utils.validators import sanitize_string, validate_amount, validate_invoice_number
from app.services.number_generator import generate_invoice_number, check_invoice_number_exists

bp = Blueprint('invoices', __name__, url_prefix='/api/invoices')

@bp.route('', methods=['GET'])
@api_login_required
def list_invoices():
    """Liste des factures"""
    # Paramètres de filtre
    client_id = request.args.get('client_id', type=int)
    company_id = request.args.get('company_id', type=int)
    start_date = request.args.get('start_date')
    end_date = request.args.get('end_date')
    search = request.args.get('search', '').strip()
    
    conn = get_db_connection()
    cursor = conn.cursor()
    
    query = '''
        SELECT 
            i.id, i.invoice_number, i.invoice_date, i.total_amount, i.reference,
            c.name as client_name,
            co.name as company_name,
            i.created_at
        FROM invoices i
        JOIN clients c ON i.client_id = c.id
        JOIN companies co ON i.company_id = co.id
        WHERE i.is_deleted = 0
    '''
    
    params = []
    
    if client_id:
        query += ' AND i.client_id = ?'
        params.append(client_id)
    
    if company_id:
        query += ' AND i.company_id = ?'
        params.append(company_id)
    
    if start_date:
        query += ' AND i.invoice_date >= ?'
        params.append(start_date)
    
    if end_date:
        query += ' AND i.invoice_date <= ?'
        params.append(end_date)
    
    if search:
        query += ' AND (i.invoice_number LIKE ? OR c.name LIKE ?)'
        params.extend([f'%{search}%', f'%{search}%'])
    
    query += ' ORDER BY i.invoice_date DESC, i.created_at DESC'
    
    cursor.execute(query, params)
    invoices = cursor.fetchall()
    conn.close()
    
    return jsonify({'success': True, 'invoices': [dict(inv) for inv in invoices]})

@bp.route('/<int:invoice_id>', methods=['GET'])
@api_login_required
def get_invoice(invoice_id):
    """Récupérer une facture avec ses articles"""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    # Facture
    cursor.execute('''
        SELECT 
            i.*,
            c.name as client_name, c.address as client_address, c.phone as client_phone,
            c.niu as client_niu, c.rc as client_rc,
            co.name as company_name, co.address as company_address, co.phone as company_phone,
            co.niu as company_niu, co.rc as company_rc
        FROM invoices i
        JOIN clients c ON i.client_id = c.id
        JOIN companies co ON i.company_id = co.id
        WHERE i.id = ?
    ''', (invoice_id,))
    
    invoice = cursor.fetchone()
    
    if not invoice:
        conn.close()
        return jsonify({'error': 'Facture non trouvée'}), 404
    
    # Articles
    cursor.execute('''
        SELECT 
            ii.id, ii.designation, ii.amount, ii.item_order,
            s.id as service_id
        FROM invoice_items ii
        JOIN services s ON ii.service_id = s.id
        WHERE ii.invoice_id = ?
        ORDER BY ii.item_order
    ''', (invoice_id,))
    
    items = cursor.fetchall()
    conn.close()
    
    result = dict(invoice)
    result['items'] = [dict(item) for item in items]
    
    return jsonify({'success': True, 'invoice': result})

@bp.route('', methods=['POST'])
@api_login_required
def create_invoice():
    """Créer une facture"""
    data = request.get_json()
    
    company_id = data.get('company_id')
    client_id = data.get('client_id')
    invoice_date = data.get('invoice_date')
    manual_number = data.get('manual_number', '').strip()
    reference = sanitize_string(data.get('reference', ''))
    additional_info = sanitize_string(data.get('additional_info', ''))
    items = data.get('items', [])
    
    # Validation
    if not all([company_id, client_id, invoice_date]):
        return jsonify({'error': 'Entreprise, client et date sont requis'}), 400
    
    if not items or len(items) == 0:
        return jsonify({'error': 'Au moins un article est requis'}), 400
    
    # Valider les articles
    total_amount = 0
    for item in items:
        if not item.get('service_id') or not item.get('designation'):
            return jsonify({'error': 'Chaque article doit avoir un service et une désignation'}), 400
        
        if not validate_amount(item.get('amount', 0)):
            return jsonify({'error': 'Montant invalide pour un article'}), 400
        
        total_amount += float(item['amount'])
    
    # Générer le numéro de facture
    try:
        date_obj = datetime.strptime(invoice_date, '%Y-%m-%d')
        invoice_number = generate_invoice_number(date_obj, manual_number if manual_number else None)
    except ValueError as e:
        return jsonify({'error': str(e)}), 400
    
    conn = get_db_connection()
    cursor = conn.cursor()
    
    try:
        # Créer la facture
        cursor.execute('''
            INSERT INTO invoices 
            (invoice_number, company_id, client_id, invoice_date, reference, additional_info, total_amount, created_by)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        ''', (invoice_number, company_id, client_id, invoice_date, reference, additional_info, total_amount, session['user_id']))
        
        invoice_id = cursor.lastrowid
        
        # Créer les articles
        for idx, item in enumerate(items):
            cursor.execute('''
                INSERT INTO invoice_items (invoice_id, service_id, designation, amount, item_order)
                VALUES (?, ?, ?, ?, ?)
            ''', (invoice_id, item['service_id'], item['designation'], item['amount'], idx))
        
        conn.commit()
        
        # Log
        log_action(session['user_id'], 'CREATE', 'invoice', invoice_id, f"Facture créée: {invoice_number}")
        
        return jsonify({'success': True, 'invoice_id': invoice_id, 'invoice_number': invoice_number})
        
    except Exception as e:
        conn.rollback()
        return jsonify({'error': str(e)}), 400
    finally:
        conn.close()

@bp.route('/<int:invoice_id>', methods=['PUT'])
@api_login_required
def update_invoice(invoice_id):
    """Mettre à jour une facture"""
    data = request.get_json()
    
    reference = sanitize_string(data.get('reference', ''))
    additional_info = sanitize_string(data.get('additional_info', ''))
    items = data.get('items', [])
    
    if not items or len(items) == 0:
        return jsonify({'error': 'Au moins un article est requis'}), 400
    
    # Valider les articles
    total_amount = 0
    for item in items:
        if not item.get('service_id') or not item.get('designation'):
            return jsonify({'error': 'Chaque article doit avoir un service et une désignation'}), 400
        
        if not validate_amount(item.get('amount', 0)):
            return jsonify({'error': 'Montant invalide pour un article'}), 400
        
        total_amount += float(item['amount'])
    
    conn = get_db_connection()
    cursor = conn.cursor()
    
    try:
        # Mettre à jour la facture
        cursor.execute('''
            UPDATE invoices
            SET reference = ?, additional_info = ?, total_amount = ?, updated_at = CURRENT_TIMESTAMP
            WHERE id = ?
        ''', (reference, additional_info, total_amount, invoice_id))
        
        # Supprimer les anciens articles
        cursor.execute('DELETE FROM invoice_items WHERE invoice_id = ?', (invoice_id,))
        
        # Créer les nouveaux articles
        for idx, item in enumerate(items):
            cursor.execute('''
                INSERT INTO invoice_items (invoice_id, service_id, designation, amount, item_order)
                VALUES (?, ?, ?, ?, ?)
            ''', (invoice_id, item['service_id'], item['designation'], item['amount'], idx))
        
        conn.commit()
        
        # Log
        log_action(session['user_id'], 'UPDATE', 'invoice', invoice_id, "Facture modifiée")
        
        return jsonify({'success': True})
        
    except Exception as e:
        conn.rollback()
        return jsonify({'error': str(e)}), 400
    finally:
        conn.close()

@bp.route('/<int:invoice_id>', methods=['DELETE'])
@api_login_required
@admin_required
def delete_invoice(invoice_id):
    """Supprimer une facture (admin uniquement)"""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    try:
        # Soft delete
        cursor.execute('''
            UPDATE invoices
            SET is_deleted = 1, deleted_by = ?, deleted_at = CURRENT_TIMESTAMP
            WHERE id = ?
        ''', (session['user_id'], invoice_id))
        
        conn.commit()
        
        # Log
        log_action(session['user_id'], 'DELETE', 'invoice', invoice_id, "Facture supprimée")
        
        return jsonify({'success': True})
        
    except Exception as e:
        conn.rollback()
        return jsonify({'error': str(e)}), 400
    finally:
        conn.close()

@bp.route('/next-number', methods=['GET'])
@api_login_required
def get_next_invoice_number():
    """Obtenir le prochain numéro de facture"""
    date_str = request.args.get('date')
    
    if not date_str:
        date_obj = datetime.now()
    else:
        try:
            date_obj = datetime.strptime(date_str, '%Y-%m-%d')
        except ValueError:
            return jsonify({'error': 'Format de date invalide'}), 400
    
    try:
        invoice_number = generate_invoice_number(date_obj)
        return jsonify({'success': True, 'invoice_number': invoice_number})
    except Exception as e:
        return jsonify({'error': str(e)}), 400

