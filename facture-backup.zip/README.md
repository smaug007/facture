# AKTIVCO Facturation - Système de Gestion de Facturation

Application desktop de gestion de facturation pour les services de dédouanement et transit portuaire au Cameroun.

## 🎯 Caractéristiques

- ✅ Gestion des entreprises émettrices
- ✅ Gestion des clients
- ✅ Catalogue de services
- ✅ Création et modification de factures
- ✅ Génération de PDF
- ✅ Export Excel
- ✅ Système d'authentification avec rôles (Admin, Saisie)
- ✅ Numérotation automatique des factures
- ✅ Conversion automatique des montants en lettres (français)
- ✅ Fonctionnement hors ligne

## 🛠️ Technologies Utilisées

- **Backend:** Python 3.10+ avec Flask
- **Frontend:** HTML5, CSS3, Bootstrap 5, Alpine.js
- **Desktop:** PyWebView
- **Base de données:** SQLite
- **PDF:** ReportLab
- **Excel:** openpyxl

## 📋 Prérequis

- Python 3.10 ou supérieur
- Système d'exploitation: Windows 10/11

## 🚀 Installation

### 1. Cloner ou copier le projet

```bash
cd D:\Apprenti\facture
```

### 2. Installer les dépendances

```bash
pip install -r requirements.txt
```

### 3. Lancer l'application

```bash
python main.py
```

## 👤 Connexion par Défaut

Au premier lancement, un compte administrateur est créé automatiquement:

- **Nom d'utilisateur:** `admin`
- **Mot de passe:** `admin123`

⚠️ **IMPORTANT:** Changez ce mot de passe immédiatement après la première connexion!

## 📁 Structure du Projet

```
facture/
├── app/
│   ├── __init__.py
│   ├── config.py
│   ├── database.py
│   ├── auth.py
│   ├── models/
│   ├── routes/
│   ├── services/
│   ├── utils/
│   └── static/
│       ├── css/
│       ├── js/
│       └── templates/
├── main.py
├── requirements.txt
├── README.md
└── IMPLEMENTATION_PLAN.md
```

## 🔐 Rôles et Permissions

### Administrateur
- Toutes les permissions
- Gestion des utilisateurs
- Suppression des factures et clients
- Accès aux paramètres système

### Saisie de Données
- Création et modification de factures
- Gestion des clients et services
- Génération de PDF et Excel
- Pas d'accès à la gestion des utilisateurs

## 📊 Fonctionnalités Principales

### 1. Gestion des Factures
- Création avec numérotation automatique (Format: XXX/MM/YYYY)
- Modification possible à tout moment
- Génération PDF professionnelle
- Export Excel pour partage
- Recherche et filtres avancés

### 2. Gestion des Clients
- Informations complètes (Nom, Adresse, NIU, RC, etc.)
- Historique des factures par client
- Templates de facturation (Phase 2)

### 3. Catalogue de Services
- Plus de 50 services pré-configurés
- Ajout de nouveaux services
- Recherche rapide

### 4. Rapports
- Statistiques du dashboard
- Rapports par client (Phase 2)
- Rapports mensuels/annuels (Phase 2)

## 🗄️ Base de Données

L'application utilise SQLite avec un fichier `factures.db` créé automatiquement au premier lancement.

**Tables principales:**
- `users` - Utilisateurs
- `companies` - Entreprises émettrices
- `clients` - Clients
- `services` - Catalogue de services
- `invoices` - Factures
- `invoice_items` - Lignes de facture

## 📄 Génération de PDF

Les factures sont générées au format PDF avec:
- En-tête professionnel
- Informations entreprise et client
- Tableau des articles
- Total en chiffres et en lettres (français)
- Mise en page propre et lisible

## 📊 Export Excel

Export des factures individuelles ou en liste pour:
- Partage entre utilisateurs
- Traitement dans Excel
- Archive externe

## 🔄 Développement par Phases

### Phase 1: MVP (En cours)
- ✅ Infrastructure de base
- ✅ Authentification
- ✅ Gestion des modules principaux
- ✅ Création de factures
- ✅ Génération PDF/Excel

### Phase 2: Fonctionnalités Avancées (À venir)
- Templates clients avec suggestions intelligentes
- Rapports avancés
- Import Excel pour partage de données

### Phase 3: Perfectionnement (À venir)
- Import des anciennes factures
- Système de sauvegarde automatique
- Optimisations de performance

## 🐛 Dépannage

### L'application ne démarre pas
1. Vérifier que Python 3.10+ est installé: `python --version`
2. Vérifier que toutes les dépendances sont installées
3. Vérifier le firewall Windows

### Erreur de base de données
- Supprimer le fichier `factures.db` et relancer (⚠️ perte de données)
- Ou contacter le support

### Problème de PDF
- Vérifier que ReportLab est installé: `pip install reportlab`
- Vérifier les permissions d'écriture dans le dossier `exports/pdf/`

## 📞 Support

Pour toute question ou problème:
- Consulter la documentation dans `/docs`
- Vérifier le fichier `IMPLEMENTATION_PLAN.md`

## 📝 Licence

© 2025 AKTIVCO CAMEROUN - Tous droits réservés

---

**Version:** 1.0.0 (MVP)  
**Date:** Novembre 2025  
**Statut:** En développement

