# Script d'installation de Python 3.12
# Pour Windows 10/11

Write-Host "========================================" -ForegroundColor Cyan
Write-Host "  Installation de Python 3.12" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""

# URL de téléchargement Python 3.12 (64-bit)
$pythonUrl = "https://www.python.org/ftp/python/3.12.0/python-3.12.0-amd64.exe"
$installerPath = "$env:TEMP\python-installer.exe"

Write-Host "Étape 1: Téléchargement de Python 3.12..." -ForegroundColor Yellow
try {
    # Télécharger l'installateur
    Invoke-WebRequest -Uri $pythonUrl -OutFile $installerPath
    Write-Host "✓ Téléchargement terminé!" -ForegroundColor Green
} catch {
    Write-Host "✗ Erreur lors du téléchargement: $_" -ForegroundColor Red
    Write-Host ""
    Write-Host "Veuillez télécharger manuellement depuis:" -ForegroundColor Yellow
    Write-Host "https://www.python.org/downloads/" -ForegroundColor Cyan
    exit 1
}

Write-Host ""
Write-Host "Étape 2: Installation de Python..." -ForegroundColor Yellow
Write-Host "IMPORTANT: L'installation va s'ouvrir." -ForegroundColor Red
Write-Host "           Cochez 'Add Python to PATH'" -ForegroundColor Red
Write-Host ""

# Lancer l'installateur
try {
    Start-Process -FilePath $installerPath -ArgumentList "/quiet InstallAllUsers=1 PrependPath=1" -Wait
    Write-Host "✓ Installation terminée!" -ForegroundColor Green
} catch {
    Write-Host "✗ Erreur lors de l'installation: $_" -ForegroundColor Red
    exit 1
}

Write-Host ""
Write-Host "Étape 3: Nettoyage..." -ForegroundColor Yellow
Remove-Item $installerPath -ErrorAction SilentlyContinue

Write-Host ""
Write-Host "========================================" -ForegroundColor Green
Write-Host "  Installation terminée avec succès!" -ForegroundColor Green
Write-Host "========================================" -ForegroundColor Green
Write-Host ""
Write-Host "IMPORTANT: Fermez et rouvrez PowerShell" -ForegroundColor Yellow
Write-Host "           pour que Python soit disponible" -ForegroundColor Yellow
Write-Host ""

# Vérifier l'installation
Write-Host "Vérification de l'installation..." -ForegroundColor Cyan
$env:Path = [System.Environment]::GetEnvironmentVariable("Path","Machine") + ";" + [System.Environment]::GetEnvironmentVariable("Path","User")
try {
    $pythonVersion = python --version 2>&1
    Write-Host "✓ Python installé: $pythonVersion" -ForegroundColor Green
} catch {
    Write-Host "⚠ Python installé mais nécessite redémarrage du terminal" -ForegroundColor Yellow
}

Write-Host ""
Write-Host "Prochaine étape: Fermez cette fenêtre et rouvrez PowerShell" -ForegroundColor Cyan
Write-Host "Puis lancez: python main.py" -ForegroundColor Cyan

