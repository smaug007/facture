# -*- coding: utf-8 -*-
"""
Services de l'application
"""

