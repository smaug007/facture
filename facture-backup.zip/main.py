# -*- coding: utf-8 -*-
"""
AKTIVCO Facturation - Point d'entrée de l'application
Application desktop de gestion de facturation
"""

import webview
import sys
import os
from threading import Thread
from app import create_app

# Créer l'application Flask
flask_app = create_app()

def start_flask():
    """Démarrer le serveur Flask"""
    flask_app.run(host='127.0.0.1', port=5000, debug=False, use_reloader=False)

def main():
    """Fonction principale"""
    # Démarrer Flask dans un thread séparé
    flask_thread = Thread(target=start_flask, daemon=True)
    flask_thread.start()
    
    # Attendre un peu que Flask démarre
    import time
    time.sleep(1)
    
    # Créer la fenêtre PyWebView
    window = webview.create_window(
        title='AKTIVCO Facturation',
        url='http://127.0.0.1:5000',
        width=1200,
        height=800,
        resizable=True,
        fullscreen=False,
        min_size=(1000, 600)
    )
    
    # Démarrer PyWebView
    webview.start(debug=False)

if __name__ == '__main__':
    try:
        print("=" * 60)
        print("   AKTIVCO Facturation - Système de Gestion")
        print("=" * 60)
        print("\nDémarrage de l'application...")
        print("Si l'application ne s'ouvre pas, vérifiez le firewall.\n")
        
        main()
        
    except KeyboardInterrupt:
        print("\n\nArrêt de l'application...")
        sys.exit(0)
    except Exception as e:
        print(f"\n\nErreur: {e}")
        input("\nAppuyez sur Entrée pour quitter...")
        sys.exit(1)

