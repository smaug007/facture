# -*- coding: utf-8 -*-
"""
Fonctions utilitaires générales
"""

from datetime import datetime
from app.config import Config

def format_date(date, format_str=None):
    """Formater une date"""
    if not date:
        return ''
    
    if isinstance(date, str):
        try:
            date = datetime.strptime(date, '%Y-%m-%d')
        except ValueError:
            return date
    
    if format_str is None:
        format_str = Config.DATE_FORMAT
    
    return date.strftime(format_str)

def format_datetime(dt):
    """Formater une date et heure"""
    if not dt:
        return ''
    
    if isinstance(dt, str):
        try:
            dt = datetime.strptime(dt, '%Y-%m-%d %H:%M:%S')
        except ValueError:
            return dt
    
    return dt.strftime(Config.DATETIME_FORMAT)

def format_amount(amount):
    """Formater un montant avec séparateurs de milliers"""
    if amount is None:
        return '0'
    
    try:
        amount = float(amount)
        # Format avec espaces comme séparateurs de milliers
        return f"{amount:,.0f}".replace(',', ' ')
    except (ValueError, TypeError):
        return '0'

def parse_date(date_str, format_str=None):
    """Parser une chaîne en date"""
    if not date_str:
        return None
    
    if format_str is None:
        format_str = Config.DATE_FORMAT
    
    try:
        return datetime.strptime(date_str, format_str)
    except ValueError:
        # Essayer le format ISO
        try:
            return datetime.strptime(date_str, '%Y-%m-%d')
        except ValueError:
            return None

def get_current_year():
    """Obtenir l'année en cours"""
    return datetime.now().year

def get_current_month():
    """Obtenir le mois en cours"""
    return datetime.now().month

def get_french_month_name(month_number):
    """Obtenir le nom français du mois"""
    months = {
        1: 'Janvier', 2: 'Février', 3: 'Mars', 4: 'Avril',
        5: 'Mai', 6: 'Juin', 7: 'Juillet', 8: 'Août',
        9: 'Septembre', 10: 'Octobre', 11: 'Novembre', 12: 'Décembre'
    }
    return months.get(month_number, '')

def format_date_french(date):
    """Formater une date en français (ex: 21 Novembre 2025)"""
    if isinstance(date, str):
        date = parse_date(date)
    
    if not date:
        return ''
    
    day = date.day
    month = get_french_month_name(date.month)
    year = date.year
    
    return f"{day:02d} {month} {year}"

