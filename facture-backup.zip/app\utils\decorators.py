# -*- coding: utf-8 -*-
"""
Décorateurs pour l'application
"""

from functools import wraps
from flask import session, jsonify, redirect, url_for

def login_required(f):
    """Décorateur pour vérifier si l'utilisateur est connecté"""
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session:
            return redirect(url_for('auth.login'))
        return f(*args, **kwargs)
    return decorated_function

def admin_required(f):
    """Décorateur pour vérifier si l'utilisateur est admin"""
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session:
            return jsonify({'error': 'Non authentifié'}), 401
        
        if session.get('role') != 'admin':
            return jsonify({'error': 'Accès refusé. Droits administrateur requis.'}), 403
        
        return f(*args, **kwargs)
    return decorated_function

def api_login_required(f):
    """Décorateur pour les routes API nécessitant une authentification"""
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session:
            return jsonify({'error': 'Non authentifié'}), 401
        return f(*args, **kwargs)
    return decorated_function

