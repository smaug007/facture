# -*- coding: utf-8 -*-
"""
Routes pour la gestion des clients
"""

from flask import Blueprint, jsonify, request, session
from app.database import get_db_connection, log_action
from app.utils.decorators import api_login_required, admin_required
from app.utils.validators import sanitize_string, validate_email, validate_phone, validate_niu, validate_rc

bp = Blueprint('clients', __name__, url_prefix='/api/clients')

@bp.route('', methods=['GET'])
@api_login_required
def list_clients():
    """Liste des clients"""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    cursor.execute('''
        SELECT id, name, address, phone, niu, rc, email, is_active, created_at
        FROM clients
        WHERE is_active = 1
        ORDER BY name
    ''')
    
    clients = cursor.fetchall()
    conn.close()
    
    return jsonify({'success': True, 'clients': [dict(c) for c in clients]})

@bp.route('/<int:client_id>', methods=['GET'])
@api_login_required
def get_client(client_id):
    """Récupérer un client"""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    cursor.execute('SELECT * FROM clients WHERE id = ?', (client_id,))
    client = cursor.fetchone()
    conn.close()
    
    if client:
        return jsonify({'success': True, 'client': dict(client)})
    else:
        return jsonify({'error': 'Client non trouvé'}), 404

@bp.route('', methods=['POST'])
@api_login_required
def create_client():
    """Créer un client"""
    data = request.get_json()
    
    name = sanitize_string(data.get('name', ''))
    address = sanitize_string(data.get('address', ''))
    phone = sanitize_string(data.get('phone', ''))
    niu = sanitize_string(data.get('niu', ''))
    rc = sanitize_string(data.get('rc', ''))
    email = sanitize_string(data.get('email', ''))
    
    # Validation
    if not all([name, address, phone, niu, rc]):
        return jsonify({'error': 'Tous les champs requis doivent être remplis'}), 400
    
    if email and not validate_email(email):
        return jsonify({'error': 'Email invalide'}), 400
    
    if not validate_phone(phone):
        return jsonify({'error': 'Numéro de téléphone invalide'}), 400
    
    if not validate_niu(niu):
        return jsonify({'error': 'NIU invalide'}), 400
    
    if not validate_rc(rc):
        return jsonify({'error': 'RC invalide'}), 400
    
    conn = get_db_connection()
    cursor = conn.cursor()
    
    try:
        cursor.execute('''
            INSERT INTO clients (name, address, phone, niu, rc, email, created_by)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        ''', (name, address, phone, niu, rc, email, session['user_id']))
        
        client_id = cursor.lastrowid
        conn.commit()
        
        # Log
        log_action(session['user_id'], 'CREATE', 'client', client_id, f"Client créé: {name}")
        
        return jsonify({'success': True, 'client_id': client_id})
        
    except Exception as e:
        conn.rollback()
        return jsonify({'error': str(e)}), 400
    finally:
        conn.close()

@bp.route('/<int:client_id>', methods=['PUT'])
@api_login_required
def update_client(client_id):
    """Mettre à jour un client"""
    data = request.get_json()
    
    name = sanitize_string(data.get('name', ''))
    address = sanitize_string(data.get('address', ''))
    phone = sanitize_string(data.get('phone', ''))
    niu = sanitize_string(data.get('niu', ''))
    rc = sanitize_string(data.get('rc', ''))
    email = sanitize_string(data.get('email', ''))
    
    # Validation
    if not all([name, address, phone, niu, rc]):
        return jsonify({'error': 'Tous les champs requis doivent être remplis'}), 400
    
    if email and not validate_email(email):
        return jsonify({'error': 'Email invalide'}), 400
    
    conn = get_db_connection()
    cursor = conn.cursor()
    
    try:
        cursor.execute('''
            UPDATE clients
            SET name = ?, address = ?, phone = ?, niu = ?, rc = ?, email = ?, updated_at = CURRENT_TIMESTAMP
            WHERE id = ?
        ''', (name, address, phone, niu, rc, email, client_id))
        
        conn.commit()
        
        # Log
        log_action(session['user_id'], 'UPDATE', 'client', client_id, f"Client modifié: {name}")
        
        return jsonify({'success': True})
        
    except Exception as e:
        conn.rollback()
        return jsonify({'error': str(e)}), 400
    finally:
        conn.close()

@bp.route('/<int:client_id>', methods=['DELETE'])
@api_login_required
@admin_required
def delete_client(client_id):
    """Supprimer un client (admin uniquement)"""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    try:
        # Soft delete
        cursor.execute('''
            UPDATE clients
            SET is_active = 0, updated_at = CURRENT_TIMESTAMP
            WHERE id = ?
        ''', (client_id,))
        
        conn.commit()
        
        # Log
        log_action(session['user_id'], 'DELETE', 'client', client_id, "Client supprimé")
        
        return jsonify({'success': True})
        
    except Exception as e:
        conn.rollback()
        return jsonify({'error': str(e)}), 400
    finally:
        conn.close()

@bp.route('/<int:client_id>/history', methods=['GET'])
@api_login_required
def client_history(client_id):
    """Historique des factures d'un client"""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    cursor.execute('''
        SELECT 
            i.id, i.invoice_number, i.invoice_date, i.total_amount, i.created_at,
            c.name as company_name
        FROM invoices i
        JOIN companies c ON i.company_id = c.id
        WHERE i.client_id = ? AND i.is_deleted = 0
        ORDER BY i.invoice_date DESC, i.created_at DESC
    ''', (client_id,))
    
    invoices = cursor.fetchall()
    conn.close()
    
    return jsonify({'success': True, 'invoices': [dict(inv) for inv in invoices]})

