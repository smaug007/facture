# Plan d'Implémentation - Système de Facturation AKTIVCO

**Date:** 21 Novembre 2025  
**Version:** 1.0  
**Statut:** En cours de développement

---

## 📋 RÉSUMÉ EXÉCUTIF

### Objectif
Développer une application desktop de gestion de facturation pour les services de dédouanement et transit portuaire au Cameroun.

### Stack Technique Choisi
- **Backend:** Python 3.10+ avec Flask
- **Frontend:** HTML5, CSS3 (Bootstrap 5), JavaScript (Alpine.js)
- **Desktop Wrapper:** PyWebView
- **Base de données:** SQLite
- **PDF:** ReportLab
- **Excel:** openpyxl

### Raisons du Choix
1. ✅ **Simplicité**: Python facile à maintenir et déboguer
2. ✅ **Légèreté**: ~50-100MB vs 200-300MB pour Electron
3. ✅ **Hors ligne**: Tout fonctionne localement sans internet
4. ✅ **Coût faible**: Pas de serveur, pas d'hébergement
5. ✅ **Évolutif**: Migration possible vers Django ou Electron plus tard
6. ✅ **Rapide**: Développement et déploiement rapides

---

## 🎯 PHASES DE DÉVELOPPEMENT

### **Phase 1: MVP (Minimum Viable Product)** - 2-3 semaines
**Objectif:** Application fonctionnelle de base pour créer et imprimer des factures

**Fonctionnalités:**
1. ✅ Authentification utilisateur (Admin, Saisie)
2. ✅ Gestion des entreprises émettrices
3. ✅ Gestion des clients
4. ✅ Catalogue de services
5. ✅ Création de factures
6. ✅ Génération PDF
7. ✅ Liste des factures
8. ✅ Paramètres système

**Livrables:**
- Application installable (.exe)
- Base de données initialisée
- Documentation utilisateur de base

---

### **Phase 2: Fonctionnalités Avancées** - 2-3 semaines
**Objectif:** Optimisation et automatisation

**Fonctionnalités:**
1. ✅ Templates de clients (articles fréquents)
2. ✅ Templates multiples par client
3. ✅ Suggestions intelligentes d'articles
4. ✅ Export Excel
5. ✅ Recherche et filtres avancés
6. ✅ Historique client complet
7. ✅ Rapports de base

**Livrables:**
- Templates fonctionnels
- Système de suggestions
- Rapports exportables

---

### **Phase 3: Perfectionnement** - 1-2 semaines
**Objectif:** Finitions et fonctionnalités additionnelles

**Fonctionnalités:**
1. ✅ Import des anciennes factures Excel
2. ✅ Système de sauvegarde automatique
3. ✅ Rapports avancés
4. ✅ Audit trail (logs d'activité)
5. ✅ Optimisations de performance

**Livrables:**
- Système complet et optimisé
- Documentation complète
- Guide de déploiement

---

## 🗄️ ARCHITECTURE DE LA BASE DE DONNÉES

### Schéma Complet

```sql
-- Table: users (Utilisateurs)
CREATE TABLE users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT NOT NULL UNIQUE,
    password_hash TEXT NOT NULL,
    full_name TEXT NOT NULL,
    role TEXT NOT NULL CHECK(role IN ('admin', 'data_entry')),
    is_active BOOLEAN DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Table: companies (Entreprises émettrices)
CREATE TABLE companies (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    address TEXT NOT NULL,
    phone TEXT NOT NULL,
    niu TEXT NOT NULL,
    rc TEXT NOT NULL,
    email TEXT,
    is_active BOOLEAN DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Table: clients
CREATE TABLE clients (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    address TEXT NOT NULL,
    phone TEXT NOT NULL,
    niu TEXT NOT NULL,
    rc TEXT NOT NULL,
    email TEXT,
    is_active BOOLEAN DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by INTEGER,
    FOREIGN KEY (created_by) REFERENCES users(id)
);

-- Table: services (Catalogue de services)
CREATE TABLE services (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    designation TEXT NOT NULL UNIQUE,
    is_active BOOLEAN DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Table: invoices (Factures)
CREATE TABLE invoices (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    invoice_number TEXT NOT NULL UNIQUE,
    company_id INTEGER NOT NULL,
    client_id INTEGER NOT NULL,
    invoice_date DATE NOT NULL,
    reference TEXT,
    additional_info TEXT,
    total_amount REAL DEFAULT 0,
    is_deleted BOOLEAN DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by INTEGER NOT NULL,
    deleted_by INTEGER,
    deleted_at TIMESTAMP,
    FOREIGN KEY (company_id) REFERENCES companies(id),
    FOREIGN KEY (client_id) REFERENCES clients(id),
    FOREIGN KEY (created_by) REFERENCES users(id),
    FOREIGN KEY (deleted_by) REFERENCES users(id)
);

-- Table: invoice_items (Lignes de facture)
CREATE TABLE invoice_items (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    invoice_id INTEGER NOT NULL,
    service_id INTEGER NOT NULL,
    designation TEXT NOT NULL,
    amount REAL NOT NULL,
    item_order INTEGER DEFAULT 0,
    FOREIGN KEY (invoice_id) REFERENCES invoices(id) ON DELETE CASCADE,
    FOREIGN KEY (service_id) REFERENCES services(id)
);

-- Table: client_templates (Templates de clients)
CREATE TABLE client_templates (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    client_id INTEGER NOT NULL,
    template_name TEXT NOT NULL,
    is_default BOOLEAN DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (client_id) REFERENCES clients(id) ON DELETE CASCADE
);

-- Table: template_items (Articles du template)
CREATE TABLE template_items (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    template_id INTEGER NOT NULL,
    service_id INTEGER NOT NULL,
    item_order INTEGER DEFAULT 0,
    FOREIGN KEY (template_id) REFERENCES client_templates(id) ON DELETE CASCADE,
    FOREIGN KEY (service_id) REFERENCES services(id)
);

-- Table: settings (Paramètres système)
CREATE TABLE settings (
    key TEXT PRIMARY KEY,
    value TEXT NOT NULL,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Table: audit_log (Journal d'audit - Phase 3)
CREATE TABLE audit_log (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER,
    action TEXT NOT NULL,
    entity_type TEXT NOT NULL,
    entity_id INTEGER,
    details TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id)
);

-- Index pour performance
CREATE INDEX idx_invoices_client ON invoices(client_id);
CREATE INDEX idx_invoices_date ON invoices(invoice_date);
CREATE INDEX idx_invoices_number ON invoices(invoice_number);
CREATE INDEX idx_invoice_items_invoice ON invoice_items(invoice_id);
CREATE INDEX idx_audit_log_user ON audit_log(user_id);
CREATE INDEX idx_audit_log_entity ON audit_log(entity_type, entity_id);
```

---

## 🏗️ STRUCTURE DU PROJET

```
facture/
├── app/
│   ├── __init__.py              # Initialisation Flask
│   ├── config.py                # Configuration
│   ├── database.py              # Connexion DB et modèles
│   ├── auth.py                  # Authentification
│   │
│   ├── models/                  # Modèles de données
│   │   ├── __init__.py
│   │   ├── user.py
│   │   ├── company.py
│   │   ├── client.py
│   │   ├── service.py
│   │   ├── invoice.py
│   │   └── template.py
│   │
│   ├── routes/                  # Routes Flask (API)
│   │   ├── __init__.py
│   │   ├── auth_routes.py
│   │   ├── company_routes.py
│   │   ├── client_routes.py
│   │   ├── service_routes.py
│   │   ├── invoice_routes.py
│   │   ├── template_routes.py
│   │   └── report_routes.py
│   │
│   ├── services/                # Logique métier
│   │   ├── __init__.py
│   │   ├── pdf_generator.py    # Génération PDF
│   │   ├── excel_exporter.py   # Export Excel
│   │   ├── number_generator.py # Numéros de facture
│   │   └── amount_converter.py # Montants en lettres
│   │
│   ├── utils/                   # Utilitaires
│   │   ├── __init__.py
│   │   ├── validators.py       # Validations
│   │   ├── decorators.py       # Décorateurs (auth, etc.)
│   │   └── helpers.py          # Fonctions helper
│   │
│   └── static/                  # Frontend
│       ├── css/
│       │   ├── bootstrap.min.css
│       │   └── custom.css
│       ├── js/
│       │   ├── alpine.min.js
│       │   ├── app.js
│       │   └── components/
│       │       ├── invoice.js
│       │       ├── client.js
│       │       └── service.js
│       └── templates/           # Templates HTML
│           ├── base.html
│           ├── login.html
│           ├── dashboard.html
│           ├── companies/
│           │   ├── list.html
│           │   └── form.html
│           ├── clients/
│           │   ├── list.html
│           │   ├── form.html
│           │   └── history.html
│           ├── services/
│           │   ├── list.html
│           │   └── form.html
│           ├── invoices/
│           │   ├── list.html
│           │   ├── create.html
│           │   ├── edit.html
│           │   └── view.html
│           ├── templates/
│           │   └── manage.html
│           ├── reports/
│           │   └── index.html
│           └── settings/
│               └── index.html
│
├── main.py                      # Point d'entrée (PyWebView)
├── requirements.txt             # Dépendances Python
├── setup.py                     # Script d'installation
├── build.py                     # Script de build .exe
├── README.md                    # Documentation
└── docs/
    ├── USER_GUIDE.md           # Guide utilisateur
    ├── INSTALLATION.md         # Guide d'installation
    └── DEVELOPER_GUIDE.md      # Guide développeur
```

---

## 🔐 SYSTÈME D'AUTHENTIFICATION

### Rôles et Permissions

| Fonctionnalité | Admin | Data Entry |
|----------------|-------|------------|
| Ajouter utilisateur | ✅ | ❌ |
| Modifier utilisateur | ✅ | ❌ |
| Supprimer utilisateur | ✅ | ❌ |
| Ajouter entreprise | ✅ | ✅ |
| Modifier entreprise | ✅ | ✅ |
| Ajouter client | ✅ | ✅ |
| Modifier client | ✅ | ✅ |
| Supprimer client | ✅ | ❌ |
| Ajouter service | ✅ | ✅ |
| Modifier service | ✅ | ✅ |
| Créer facture | ✅ | ✅ |
| Modifier facture | ✅ | ✅ |
| Supprimer facture | ✅ | ❌ |
| Voir rapports | ✅ | ✅ |
| Paramètres système | ✅ | ❌ |

### Implémentation

```python
# Décorateur pour vérifier les permissions
def admin_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if session.get('role') != 'admin':
            return jsonify({'error': 'Accès refusé'}), 403
        return f(*args, **kwargs)
    return decorated_function

# Utilisation
@app.route('/api/users/add', methods=['POST'])
@login_required
@admin_required
def add_user():
    # Code ici
    pass
```

---

## 📄 GÉNÉRATION DE FACTURES

### Format PDF

**Éléments:**
1. En-tête: Date et lieu (Douala, le XX Mois YYYY)
2. Informations entreprise émettrice
3. Informations client
4. Numéro de facture
5. Références (texte libre)
6. Tableau des articles
7. Total (chiffres et lettres)
8. Signature

### Template PDF (Structure)

```
┌─────────────────────────────────────────────────────────┐
│                 Douala, le 21 Novembre 2025             │
│                                                          │
│                   AKTIVCO CAMEROUN                       │
│              Bpriso-à côté du cub snec                  │
│              BP : 2407 Bpriso-DOUALA                    │
│              Tel : (237) 696 279 801                    │
│              NIU : M101914203431F                       │
│              RC : RC/06/B/380                           │
│                                                          │
│  Facture N° 001/11/2025                                 │
│                                                          │
│  Références: [Texte libre]                              │
│                                                          │
│  ┌────────────────────────────────────┬──────────────┐ │
│  │ Désignation                        │ Montant      │ │
│  ├────────────────────────────────────┼──────────────┤ │
│  │ Frais de dossier                   │ 72 700       │ │
│  │ Assurance                          │ 91 477       │ │
│  │ Vacation Douane                    │ 50 000       │ │
│  ├────────────────────────────────────┼──────────────┤ │
│  │ NET A PAYER                        │ 214 177      │ │
│  └────────────────────────────────────┴──────────────┘ │
│                                                          │
│  Arrêté la présente facture à la somme de FCFA :       │
│  Deux cent quatorze mille cent soixante dix sept        │
│                                                          │
│                                 La Directrice            │
└─────────────────────────────────────────────────────────┘
```

### Conversion Montant en Lettres (Français)

```python
def amount_to_french_words(amount):
    """
    Convertit un montant numérique en lettres (français)
    Exemple: 1353526 → "Un million trois cent cinquante trois mille cinq cent vingt six"
    """
    # Implémentation complète dans services/amount_converter.py
    pass
```

---

## 🔢 SYSTÈME DE NUMÉROTATION

### Format: `XXX/MM/YYYY`

- **XXX**: Numéro séquentiel (001, 002, ...)
- **MM**: Mois (01-12)
- **YYYY**: Année (2025, 2026, ...)

### Règles:
1. Auto-incrémentation annuelle (reset au 01/01 de chaque année)
2. Modification manuelle possible (admin/data entry)
3. Vérification d'unicité
4. Format avec zéros devant (001, 002, ..., 099, 100, ...)

### Implémentation

```python
def generate_invoice_number(date, manual_number=None):
    """
    Génère le prochain numéro de facture
    Args:
        date: Date de la facture
        manual_number: Numéro manuel si spécifié
    Returns:
        str: Numéro de facture (ex: "001/11/2025")
    """
    month = date.strftime("%m")
    year = date.strftime("%Y")
    
    if manual_number:
        # Vérifier si le numéro existe déjà
        invoice_num = f"{manual_number:03d}/{month}/{year}"
        if invoice_exists(invoice_num):
            raise ValueError("Ce numéro de facture existe déjà")
        return invoice_num
    
    # Auto-génération
    last_invoice = get_last_invoice_of_year(year)
    if last_invoice:
        # Extraire le numéro séquentiel
        seq = int(last_invoice.invoice_number.split('/')[0]) + 1
    else:
        seq = 1
    
    return f"{seq:03d}/{month}/{year}"
```

---

## 🎨 INTERFACE UTILISATEUR

### Stack Frontend
- **Bootstrap 5**: Framework CSS pour design moderne et responsive
- **Alpine.js**: Framework JavaScript léger pour interactivité
- **Font Awesome**: Icônes
- **DataTables** (optionnel): Pour tableaux avec tri/recherche

### Écrans Principaux

#### 1. Login
- Champ username
- Champ password
- Bouton "Se connecter"
- Message d'erreur si échec

#### 2. Dashboard
- Statistiques rapides:
  - Nombre de factures ce mois
  - Total facturé ce mois
  - Nombre de clients actifs
  - Dernières factures créées

#### 3. Gestion Clients
- Liste: Tableau avec nom, NIU, RC, téléphone, actions
- Formulaire: Tous les champs requis
- Historique: Liste des factures du client

#### 4. Gestion Services
- Liste: Tableau avec désignation, statut, actions
- Formulaire: Champ désignation

#### 5. Création Facture
**Étapes:**
1. Sélectionner entreprise émettrice
2. Sélectionner client
3. Sélectionner date
4. Entrer références (optionnel)
5. Ajouter articles (désignation + montant)
6. Aperçu total
7. Générer PDF

**Fonctionnalités:**
- Charger template client (si existe)
- Ajouter articles depuis catalogue
- Supprimer articles
- Réorganiser ordre des articles
- Calcul automatique du total
- Prévisualisation

#### 6. Liste Factures
- Tableau: N°, Date, Client, Montant, Actions
- Filtres: Date, Client, Entreprise
- Recherche: Par numéro ou nom client
- Actions: Voir, Modifier, PDF, Excel, Supprimer (admin)

#### 7. Templates Client
- Liste des templates par client
- Créer nouveau template
- Modifier template existant
- Définir template par défaut
- Suggestions basées sur historique

---

## 📊 RAPPORTS

### Phase 2 - Rapports de Base

1. **Rapport par Client**
   - Total facturé par client
   - Nombre de factures
   - Période sélectionnable

2. **Rapport Mensuel**
   - Factures du mois
   - Total du mois
   - Répartition par client

3. **Rapport Annuel**
   - Factures de l'année
   - Total de l'année
   - Graphique mensuel

### Export
- PDF (pour impression)
- Excel (pour traitement)

---

## 🔧 CONFIGURATION & PARAMÈTRES

### Paramètres Système

**Accessibles via Settings (Admin uniquement):**
1. Année fiscale en cours
2. Numéro de démarrage des factures
3. Format de date par défaut
4. Langue (pour l'instant: Français uniquement)
5. Chemin de sauvegarde PDF

### Base de Données Settings

```sql
INSERT INTO settings (key, value) VALUES
('fiscal_year', '2025'),
('invoice_start_number', '1'),
('date_format', 'DD/MM/YYYY'),
('language', 'fr'),
('pdf_save_path', 'C:/Factures/PDF'),
('auto_backup', '1'),
('backup_frequency', 'daily');
```

---

## 📦 DÉPLOIEMENT

### Création de l'Exécutable

**Outil:** PyInstaller

```bash
# Installation
pip install pyinstaller

# Build
pyinstaller --onefile --windowed --icon=icon.ico --name="AKTIVCO Facturation" main.py

# Résultat: dist/AKTIVCO Facturation.exe
```

### Installation Utilisateur

**Méthode Simple:**
1. Copier le dossier complet sur le PC
2. Double-cliquer sur `AKTIVCO Facturation.exe`
3. L'application se lance

**Première Utilisation:**
- Base de données créée automatiquement
- Compte admin par défaut créé:
  - Username: `admin`
  - Password: `admin123` (à changer immédiatement)

### Partage entre Utilisateurs

**Important:** Chaque installation est indépendante (pas de base partagée)

**Pour partager une facture:**
1. Utilisateur A crée la facture
2. Utilisateur A exporte en Excel
3. Utilisateur A envoie le fichier à Utilisateur B
4. Utilisateur B ouvre le fichier Excel
5. Utilisateur B peut importer ou juste consulter

---

## 🧪 TESTS

### Tests Unitaires (Phase 3)
- Tests des modèles
- Tests des services (PDF, Excel, etc.)
- Tests des utilitaires

### Tests d'Intégration
- Tests des routes API
- Tests de génération PDF
- Tests d'export Excel

### Tests Manuels
- Scénarios utilisateur complets
- Tests sur Windows 10/11
- Tests avec données réelles

---

## 📝 DONNÉES INITIALES

### Services Fréquents (À pré-remplir)

D'après l'analyse de l'Excel:

**Services généraux:**
1. Frais de dossier
2. Frais fixe de dossier
3. Assurance
4. Fiche Guichet Unique
5. Redevance PAK
6. Redevance PAD
7. Frais de mise à disposition conteneur
8. Kribi Port Inspection
9. Sortie conteneur
10. Vacation Douane
11. Acconage KCT
12. Acconage RTC
13. Frais Pesée
14. Transport pour Livraison Kribi-Douala-Kribi
15. Transport pour Livraison
16. TEL informatique et deblocage ASIE
17. TEL sortie
18. TEL Informatique
19. TEL Douane
20. TEL Informatique et Facilitation
21. Frais APM
22. Factures MAERSK
23. Factures MSC
24. Factures CMA
25. Droits de douane ESTIMATIFS
26. Frais Bancaire
27. Frais de banque
28. Authentification lettre d'Exo
29. Frais Procuration
30. Frais de visite et caution
31. Timbre sur BL
32. Manipulation
33. Manutention-Manipulation
34. Remise documentaire ADC
35. Remise documentaire DHL
36. BESC
37. Phytosanitaire
38. Declaration d'importation
39. Certificat de contrôle Sanitaire
40. Frais telex release
41. Frais release
42. Frais d'Estempillage
43. Surestaries
44. Stationnement
45. Encombrement et stationement
46. Detention TC
47. Retour Vide
48. Frais de retour vide
49. Container clean CMA
50. Container MEDLOG
51. Annulation annuelle Precompte
52. Inscription au fichier des Exportateurs

### Script d'Initialisation

```python
def initialize_default_services():
    """Crée les services par défaut dans la base de données"""
    services = [
        "Frais de dossier",
        "Assurance",
        "Vacation Douane",
        # ... (liste complète ci-dessus)
    ]
    
    for service in services:
        if not service_exists(service):
            create_service(service)
```

---

## ⚠️ RISQUES & MITIGATIONS

### Risques Identifiés

1. **Perte de données**
   - Mitigation: Backup automatique (Phase 3)
   - Solution temporaire: Utilisateurs copient manuellement le fichier DB

2. **Corruption de base de données**
   - Mitigation: Validation stricte des données
   - Solution: Script de réparation DB

3. **Conflits de numéros de facture**
   - Mitigation: Vérification d'unicité à chaque création
   - Lock sur la table lors de la génération

4. **Utilisateurs multiples sur même PC**
   - Mitigation: Système de login
   - Chaque utilisateur a son compte

5. **Erreurs de montant (calcul)**
   - Mitigation: Validation côté serveur
   - Double vérification avant enregistrement

---

## 🚀 ORDRE D'IMPLÉMENTATION (Phase 1)

### Semaine 1: Infrastructure
1. Setup projet Python
2. Installer dépendances
3. Créer structure de fichiers
4. Base de données + modèles
5. Système d'authentification
6. Interface de login

### Semaine 2: Modules de base
1. Gestion entreprises
2. Gestion clients
3. Gestion services
4. Dashboard simple

### Semaine 3: Facturation
1. Création facture (interface)
2. Génération PDF
3. Liste factures
4. Recherche/filtres basiques
5. Tests complets

---

## 📚 DÉPENDANCES PYTHON

```txt
# requirements.txt
Flask==3.0.0
Flask-Session==0.5.0
pywebview==4.4.1
reportlab==4.0.7
openpyxl==3.1.2
Werkzeug==3.0.1
num2words==0.5.13
Pillow==10.1.0
PyInstaller==6.3.0
```

---

## 🎯 CRITÈRES DE SUCCÈS

### Phase 1 (MVP)
- [ ] Application se lance sans erreur
- [ ] Login fonctionne
- [ ] Peut créer un client
- [ ] Peut créer une facture
- [ ] PDF généré est lisible et correct
- [ ] Numérotation automatique fonctionne
- [ ] Liste des factures affiche correctement

### Phase 2
- [ ] Templates clients fonctionnent
- [ ] Suggestions intelligentes précises
- [ ] Export Excel fonctionnel
- [ ] Rapports générés correctement

### Phase 3
- [ ] Import données anciennes réussi
- [ ] Backup automatique fonctionne
- [ ] Performance acceptable (< 2s chargement)
- [ ] Aucun bug critique

---

## 📞 QUESTIONS EN SUSPENS

**Aucune** - Toutes les questions clarifiées avec le client.

---

## 🔄 MÉTHODOLOGIE DE DÉVELOPPEMENT

### Approche
1. **Développement itératif**: Construire fonctionnalité par fonctionnalité
2. **Tests continus**: Tester chaque module avant de passer au suivant
3. **Feedback régulier**: Montrer progression au client
4. **Documentation au fur et à mesure**: Ne pas attendre la fin

### Outils
- **Git**: Versioning du code
- **VS Code**: Éditeur
- **DB Browser for SQLite**: Visualisation base de données
- **Postman** (optionnel): Tests API

---

## ✅ CONCLUSION

Ce plan couvre tous les aspects techniques et fonctionnels du système de facturation. L'approche en 3 phases permet:

1. **Livraison rapide** d'un MVP fonctionnel
2. **Validation** avec utilisateurs réels
3. **Ajustements** basés sur feedback
4. **Perfectionnement** progressif

**Prochaine étape:** Commencer l'implémentation Phase 1.

**Date de début prévue:** 21 Novembre 2025  
**Date de livraison MVP prévue:** Décembre 2025

---

**Document rédigé par:** Assistant IA  
**Validé par:** Client  
**Statut:** Prêt pour implémentation


