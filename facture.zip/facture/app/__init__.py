# -*- coding: utf-8 -*-
"""
AKTIVCO Facturation - Application Factory
Initialisation de l'application Flask
"""

from flask import Flask
from flask_session import Session
import os

def create_app():
    """Créer et configurer l'application Flask"""
    
    app = Flask(__name__, 
                static_folder='static',
                template_folder='static/templates')
    
    # Configuration
    app.config.from_object('app.config.Config')
    
    # Session
    Session(app)
    
    # Initialiser la base de données
    from app.database import init_db, create_default_admin
    init_db()
    create_default_admin()
    
    # Enregistrer les routes
    from app.routes import auth_routes, company_routes, client_routes
    from app.routes import service_routes, invoice_routes, report_routes
    
    app.register_blueprint(auth_routes.bp)
    app.register_blueprint(company_routes.bp)
    app.register_blueprint(client_routes.bp)
    app.register_blueprint(service_routes.bp)
    app.register_blueprint(invoice_routes.bp)
    app.register_blueprint(report_routes.bp)
    
    # Routes racine et dashboard
    from flask import redirect, url_for, render_template, session
    from app.utils.decorators import login_required
    
    @app.route('/')
    def index():
        if 'user_id' in session:
            return redirect(url_for('dashboard'))
        return redirect(url_for('auth.login'))
    
    @app.route('/dashboard')
    @login_required
    def dashboard():
        return render_template('dashboard.html')
    
    return app

