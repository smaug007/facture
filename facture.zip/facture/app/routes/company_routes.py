# -*- coding: utf-8 -*-
"""
Routes pour la gestion des entreprises émettrices
"""

from flask import Blueprint, jsonify, request, session
from app.database import get_db_connection, log_action
from app.utils.decorators import api_login_required
from app.utils.validators import sanitize_string, validate_email, validate_phone, validate_niu, validate_rc

bp = Blueprint('companies', __name__, url_prefix='/api/companies')

@bp.route('', methods=['GET'])
@api_login_required
def list_companies():
    """Liste des entreprises"""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    cursor.execute('''
        SELECT id, name, address, phone, niu, rc, email, is_active, created_at
        FROM companies
        WHERE is_active = 1
        ORDER BY name
    ''')
    
    companies = cursor.fetchall()
    conn.close()
    
    return jsonify({'success': True, 'companies': [dict(c) for c in companies]})

@bp.route('/<int:company_id>', methods=['GET'])
@api_login_required
def get_company(company_id):
    """Récupérer une entreprise"""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    cursor.execute('SELECT * FROM companies WHERE id = ?', (company_id,))
    company = cursor.fetchone()
    conn.close()
    
    if company:
        return jsonify({'success': True, 'company': dict(company)})
    else:
        return jsonify({'error': 'Entreprise non trouvée'}), 404

@bp.route('', methods=['POST'])
@api_login_required
def create_company():
    """Créer une entreprise"""
    data = request.get_json()
    
    name = sanitize_string(data.get('name', ''))
    address = sanitize_string(data.get('address', ''))
    phone = sanitize_string(data.get('phone', ''))
    niu = sanitize_string(data.get('niu', ''))
    rc = sanitize_string(data.get('rc', ''))
    email = sanitize_string(data.get('email', ''))
    
    # Validation
    if not all([name, address, phone, niu, rc]):
        return jsonify({'error': 'Tous les champs requis doivent être remplis'}), 400
    
    if email and not validate_email(email):
        return jsonify({'error': 'Email invalide'}), 400
    
    if not validate_phone(phone):
        return jsonify({'error': 'Numéro de téléphone invalide'}), 400
    
    if not validate_niu(niu):
        return jsonify({'error': 'NIU invalide'}), 400
    
    if not validate_rc(rc):
        return jsonify({'error': 'RC invalide'}), 400
    
    conn = get_db_connection()
    cursor = conn.cursor()
    
    try:
        cursor.execute('''
            INSERT INTO companies (name, address, phone, niu, rc, email)
            VALUES (?, ?, ?, ?, ?, ?)
        ''', (name, address, phone, niu, rc, email))
        
        company_id = cursor.lastrowid
        conn.commit()
        
        # Log
        log_action(session['user_id'], 'CREATE', 'company', company_id, f"Entreprise créée: {name}")
        
        return jsonify({'success': True, 'company_id': company_id})
        
    except Exception as e:
        conn.rollback()
        return jsonify({'error': str(e)}), 400
    finally:
        conn.close()

@bp.route('/<int:company_id>', methods=['PUT'])
@api_login_required
def update_company(company_id):
    """Mettre à jour une entreprise"""
    data = request.get_json()
    
    name = sanitize_string(data.get('name', ''))
    address = sanitize_string(data.get('address', ''))
    phone = sanitize_string(data.get('phone', ''))
    niu = sanitize_string(data.get('niu', ''))
    rc = sanitize_string(data.get('rc', ''))
    email = sanitize_string(data.get('email', ''))
    
    # Validation
    if not all([name, address, phone, niu, rc]):
        return jsonify({'error': 'Tous les champs requis doivent être remplis'}), 400
    
    if email and not validate_email(email):
        return jsonify({'error': 'Email invalide'}), 400
    
    conn = get_db_connection()
    cursor = conn.cursor()
    
    try:
        cursor.execute('''
            UPDATE companies
            SET name = ?, address = ?, phone = ?, niu = ?, rc = ?, email = ?, updated_at = CURRENT_TIMESTAMP
            WHERE id = ?
        ''', (name, address, phone, niu, rc, email, company_id))
        
        conn.commit()
        
        # Log
        log_action(session['user_id'], 'UPDATE', 'company', company_id, f"Entreprise modifiée: {name}")
        
        return jsonify({'success': True})
        
    except Exception as e:
        conn.rollback()
        return jsonify({'error': str(e)}), 400
    finally:
        conn.close()


