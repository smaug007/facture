# -*- coding: utf-8 -*-
"""
Routes pour la gestion du catalogue de services
"""

from flask import Blueprint, jsonify, request, session
from app.database import get_db_connection, log_action
from app.utils.decorators import api_login_required
from app.utils.validators import sanitize_string

bp = Blueprint('services', __name__, url_prefix='/api/services')

@bp.route('', methods=['GET'])
@api_login_required
def list_services():
    """Liste des services"""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    cursor.execute('''
        SELECT id, designation, is_active, created_at
        FROM services
        WHERE is_active = 1
        ORDER BY designation
    ''')
    
    services = cursor.fetchall()
    conn.close()
    
    return jsonify({'success': True, 'services': [dict(s) for s in services]})

@bp.route('/<int:service_id>', methods=['GET'])
@api_login_required
def get_service(service_id):
    """Récupérer un service"""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    cursor.execute('SELECT * FROM services WHERE id = ?', (service_id,))
    service = cursor.fetchone()
    conn.close()
    
    if service:
        return jsonify({'success': True, 'service': dict(service)})
    else:
        return jsonify({'error': 'Service non trouvé'}), 404

@bp.route('', methods=['POST'])
@api_login_required
def create_service():
    """Créer un service"""
    data = request.get_json()
    
    designation = sanitize_string(data.get('designation', ''))
    
    if not designation:
        return jsonify({'error': 'La désignation est requise'}), 400
    
    conn = get_db_connection()
    cursor = conn.cursor()
    
    try:
        cursor.execute('''
            INSERT INTO services (designation)
            VALUES (?)
        ''', (designation,))
        
        service_id = cursor.lastrowid
        conn.commit()
        
        # Log
        log_action(session['user_id'], 'CREATE', 'service', service_id, f"Service créé: {designation}")
        
        return jsonify({'success': True, 'service_id': service_id})
        
    except Exception as e:
        conn.rollback()
        if 'UNIQUE constraint failed' in str(e):
            return jsonify({'error': 'Ce service existe déjà'}), 400
        return jsonify({'error': str(e)}), 400
    finally:
        conn.close()

@bp.route('/<int:service_id>', methods=['PUT'])
@api_login_required
def update_service(service_id):
    """Mettre à jour un service"""
    data = request.get_json()
    
    designation = sanitize_string(data.get('designation', ''))
    
    if not designation:
        return jsonify({'error': 'La désignation est requise'}), 400
    
    conn = get_db_connection()
    cursor = conn.cursor()
    
    try:
        cursor.execute('''
            UPDATE services
            SET designation = ?, updated_at = CURRENT_TIMESTAMP
            WHERE id = ?
        ''', (designation, service_id))
        
        conn.commit()
        
        # Log
        log_action(session['user_id'], 'UPDATE', 'service', service_id, f"Service modifié: {designation}")
        
        return jsonify({'success': True})
        
    except Exception as e:
        conn.rollback()
        if 'UNIQUE constraint failed' in str(e):
            return jsonify({'error': 'Ce service existe déjà'}), 400
        return jsonify({'error': str(e)}), 400
    finally:
        conn.close()

@bp.route('/search', methods=['GET'])
@api_login_required
def search_services():
    """Rechercher des services"""
    query = request.args.get('q', '').strip()
    
    if not query:
        return jsonify({'success': True, 'services': []})
    
    conn = get_db_connection()
    cursor = conn.cursor()
    
    cursor.execute('''
        SELECT id, designation
        FROM services
        WHERE designation LIKE ? AND is_active = 1
        ORDER BY designation
        LIMIT 20
    ''', (f'%{query}%',))
    
    services = cursor.fetchall()
    conn.close()
    
    return jsonify({'success': True, 'services': [dict(s) for s in services]})


