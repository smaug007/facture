# -*- coding: utf-8 -*-
"""
Routes d'authentification
"""

from flask import Blueprint, render_template, request, jsonify, session, redirect, url_for
from app.auth import authenticate_user, get_all_users, create_user, update_user_password, deactivate_user
from app.utils.decorators import login_required, admin_required, api_login_required
from app.utils.validators import sanitize_string

bp = Blueprint('auth', __name__, url_prefix='/auth')

@bp.route('/login', methods=['GET'])
def login():
    """Page de connexion"""
    if 'user_id' in session:
        return redirect(url_for('dashboard'))
    
    return render_template('login.html')

@bp.route('/login', methods=['POST'])
def login_post():
    """Traiter la connexion"""
    data = request.get_json()
    
    username = sanitize_string(data.get('username', ''))
    password = data.get('password', '')
    
    if not username or not password:
        return jsonify({'error': 'Nom d\'utilisateur et mot de passe requis'}), 400
    
    user = authenticate_user(username, password)
    
    if user:
        # Créer la session
        session['user_id'] = user['id']
        session['username'] = user['username']
        session['full_name'] = user['full_name']
        session['role'] = user['role']
        session.permanent = True
        
        return jsonify({
            'success': True,
            'user': user,
            'redirect': url_for('dashboard')
        })
    else:
        return jsonify({'error': 'Nom d\'utilisateur ou mot de passe incorrect'}), 401

@bp.route('/logout', methods=['POST'])
@api_login_required
def logout():
    """Déconnexion"""
    session.clear()
    return jsonify({'success': True, 'redirect': url_for('auth.login')})

@bp.route('/users', methods=['GET'])
@api_login_required
@admin_required
def list_users():
    """Liste des utilisateurs (admin uniquement)"""
    users = get_all_users()
    return jsonify({'success': True, 'users': users})

@bp.route('/users/create', methods=['POST'])
@api_login_required
@admin_required
def create_user_route():
    """Créer un nouvel utilisateur (admin uniquement)"""
    data = request.get_json()
    
    username = sanitize_string(data.get('username', ''))
    password = data.get('password', '')
    full_name = sanitize_string(data.get('full_name', ''))
    role = data.get('role', 'data_entry')
    
    # Validation
    if not username or not password or not full_name:
        return jsonify({'error': 'Tous les champs sont requis'}), 400
    
    if role not in ['admin', 'data_entry']:
        return jsonify({'error': 'Rôle invalide'}), 400
    
    if len(password) < 6:
        return jsonify({'error': 'Le mot de passe doit contenir au moins 6 caractères'}), 400
    
    result = create_user(username, password, full_name, role, session['user_id'])
    
    if result['success']:
        return jsonify({'success': True, 'user_id': result['user_id']})
    else:
        return jsonify({'error': result.get('error', 'Erreur lors de la création')}), 400

@bp.route('/users/<int:user_id>/password', methods=['PUT'])
@api_login_required
def change_password(user_id):
    """Changer le mot de passe"""
    # Un utilisateur peut changer son propre mot de passe, ou admin peut changer n'importe quel mot de passe
    if session['user_id'] != user_id and session['role'] != 'admin':
        return jsonify({'error': 'Accès refusé'}), 403
    
    data = request.get_json()
    new_password = data.get('new_password', '')
    
    if len(new_password) < 6:
        return jsonify({'error': 'Le mot de passe doit contenir au moins 6 caractères'}), 400
    
    result = update_user_password(user_id, new_password, session['user_id'])
    
    if result['success']:
        return jsonify({'success': True})
    else:
        return jsonify({'error': result.get('error', 'Erreur lors de la modification')}), 400

@bp.route('/users/<int:user_id>/deactivate', methods=['PUT'])
@api_login_required
@admin_required
def deactivate_user_route(user_id):
    """Désactiver un utilisateur (admin uniquement)"""
    # Ne pas permettre de se désactiver soi-même
    if session['user_id'] == user_id:
        return jsonify({'error': 'Vous ne pouvez pas désactiver votre propre compte'}), 400
    
    result = deactivate_user(user_id, session['user_id'])
    
    if result['success']:
        return jsonify({'success': True})
    else:
        return jsonify({'error': result.get('error', 'Erreur lors de la désactivation')}), 400


