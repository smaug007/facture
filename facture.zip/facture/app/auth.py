# -*- coding: utf-8 -*-
"""
Gestion de l'authentification
"""

from werkzeug.security import check_password_hash, generate_password_hash
from app.database import get_db_connection, log_action

def authenticate_user(username, password):
    """Authentifier un utilisateur"""
    
    conn = get_db_connection()
    cursor = conn.cursor()
    
    cursor.execute('''
        SELECT id, username, password_hash, full_name, role, is_active
        FROM users
        WHERE username = ?
    ''', (username,))
    
    user = cursor.fetchone()
    conn.close()
    
    if user and user['is_active'] and check_password_hash(user['password_hash'], password):
        # Log de connexion
        log_action(user['id'], 'LOGIN', 'user', user['id'], f"Connexion réussie: {username}")
        
        return {
            'id': user['id'],
            'username': user['username'],
            'full_name': user['full_name'],
            'role': user['role']
        }
    
    return None

def get_user_by_id(user_id):
    """Récupérer un utilisateur par son ID"""
    
    conn = get_db_connection()
    cursor = conn.cursor()
    
    cursor.execute('''
        SELECT id, username, full_name, role, is_active, created_at
        FROM users
        WHERE id = ? AND is_active = 1
    ''', (user_id,))
    
    user = cursor.fetchone()
    conn.close()
    
    if user:
        return dict(user)
    
    return None

def get_all_users():
    """Récupérer tous les utilisateurs"""
    
    conn = get_db_connection()
    cursor = conn.cursor()
    
    cursor.execute('''
        SELECT id, username, full_name, role, is_active, created_at
        FROM users
        ORDER BY created_at DESC
    ''')
    
    users = cursor.fetchall()
    conn.close()
    
    return [dict(user) for user in users]

def create_user(username, password, full_name, role, created_by):
    """Créer un nouvel utilisateur"""
    
    conn = get_db_connection()
    cursor = conn.cursor()
    
    try:
        password_hash = generate_password_hash(password)
        
        cursor.execute('''
            INSERT INTO users (username, password_hash, full_name, role)
            VALUES (?, ?, ?, ?)
        ''', (username, password_hash, full_name, role))
        
        user_id = cursor.lastrowid
        conn.commit()
        
        # Log de création
        log_action(created_by, 'CREATE', 'user', user_id, f"Utilisateur créé: {username}")
        
        return {'success': True, 'user_id': user_id}
        
    except Exception as e:
        conn.rollback()
        return {'success': False, 'error': str(e)}
    finally:
        conn.close()

def update_user_password(user_id, new_password, updated_by):
    """Mettre à jour le mot de passe d'un utilisateur"""
    
    conn = get_db_connection()
    cursor = conn.cursor()
    
    try:
        password_hash = generate_password_hash(new_password)
        
        cursor.execute('''
            UPDATE users
            SET password_hash = ?, updated_at = CURRENT_TIMESTAMP
            WHERE id = ?
        ''', (password_hash, user_id))
        
        conn.commit()
        
        # Log de modification
        log_action(updated_by, 'UPDATE', 'user', user_id, "Mot de passe modifié")
        
        return {'success': True}
        
    except Exception as e:
        conn.rollback()
        return {'success': False, 'error': str(e)}
    finally:
        conn.close()

def deactivate_user(user_id, deactivated_by):
    """Désactiver un utilisateur"""
    
    conn = get_db_connection()
    cursor = conn.cursor()
    
    try:
        cursor.execute('''
            UPDATE users
            SET is_active = 0, updated_at = CURRENT_TIMESTAMP
            WHERE id = ?
        ''', (user_id,))
        
        conn.commit()
        
        # Log de désactivation
        log_action(deactivated_by, 'DEACTIVATE', 'user', user_id, "Utilisateur désactivé")
        
        return {'success': True}
        
    except Exception as e:
        conn.rollback()
        return {'success': False, 'error': str(e)}
    finally:
        conn.close()


