# -*- coding: utf-8 -*-
"""
Génération de factures en PDF
"""

import os
from reportlab.lib.pagesizes import A4
from reportlab.lib.units import mm
from reportlab.pdfgen import canvas
from reportlab.lib import colors
from reportlab.platypus import Table, TableStyle
from datetime import datetime
from app.utils.helpers import format_amount, format_date_french
from app.services.amount_converter import amount_to_french_words
from app.config import Config

def generate_invoice_pdf(invoice_data, output_path=None):
    """
    Générer une facture en PDF
    
    Args:
        invoice_data: Dictionnaire contenant toutes les données de la facture
        output_path: Chemin de sortie (optionnel, sinon généré automatiquement)
    
    Returns:
        str: Chemin du fichier PDF généré
    """
    
    # Générer le nom de fichier si non fourni
    if not output_path:
        filename = f"Facture_{invoice_data['invoice_number'].replace('/', '_')}.pdf"
        output_path = os.path.join(Config.PDF_EXPORT_FOLDER, filename)
    
    # Créer le PDF
    c = canvas.Canvas(output_path, pagesize=A4)
    width, height = A4
    
    # Position Y courante
    y = height - 30*mm
    
    # Date et lieu (en haut à droite)
    date_str = format_date_french(invoice_data['invoice_date'])
    c.setFont("Helvetica", 11)
    c.drawRightString(width - 30*mm, y, f"Douala, le {date_str}")
    
    y -= 15*mm
    
    # Informations entreprise émettrice (centrées)
    c.setFont("Helvetica-Bold", 13)
    c.drawCentredString(width/2, y, invoice_data['company_name'].upper())
    y -= 5*mm
    
    c.setFont("Helvetica", 10)
    c.drawCentredString(width/2, y, invoice_data['company_address'])
    y -= 5*mm
    
    c.drawCentredString(width/2, y, f"Tel : {invoice_data['company_phone']}")
    y -= 5*mm
    
    c.drawCentredString(width/2, y, f"NIU : {invoice_data['company_niu']}")
    y -= 5*mm
    
    c.drawCentredString(width/2, y, f"RC : {invoice_data['company_rc']}")
    y -= 10*mm
    
    # Numéro de facture
    c.setFont("Helvetica-Bold", 12)
    c.drawString(30*mm, y, f"Facture N° {invoice_data['invoice_number']}")
    y -= 10*mm
    
    # Informations client (si disponibles)
    if invoice_data.get('client_name'):
        c.setFont("Helvetica", 10)
        c.drawString(30*mm, y, f"Client: {invoice_data['client_name']}")
        y -= 5*mm
    
    # Références
    if invoice_data.get('reference'):
        c.setFont("Helvetica", 10)
        c.drawString(30*mm, y, f"Références: {invoice_data['reference']}")
        y -= 5*mm
    
    if invoice_data.get('additional_info'):
        c.setFont("Helvetica", 9)
        # Gérer le texte multiligne
        lines = invoice_data['additional_info'].split('\n')
        for line in lines[:3]:  # Max 3 lignes
            c.drawString(30*mm, y, line)
            y -= 4*mm
    
    y -= 5*mm
    
    # Tableau des articles
    table_data = [['Désignation', 'Montant']]
    
    for item in invoice_data['items']:
        table_data.append([
            item['designation'],
            format_amount(item['amount'])
        ])
    
    # Ligne NET A PAYER
    table_data.append([
        'NET A PAYER',
        format_amount(invoice_data['total_amount'])
    ])
    
    # Créer le tableau
    table = Table(table_data, colWidths=[120*mm, 40*mm])
    table.setStyle(TableStyle([
        # En-tête
        ('BACKGROUND', (0, 0), (-1, 0), colors.lightgrey),
        ('TEXTCOLOR', (0, 0), (-1, 0), colors.black),
        ('ALIGN', (0, 0), (-1, 0), 'CENTER'),
        ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
        ('FONTSIZE', (0, 0), (-1, 0), 11),
        ('BOTTOMPADDING', (0, 0), (-1, 0), 8),
        
        # Corps du tableau
        ('FONTNAME', (0, 1), (-1, -2), 'Helvetica'),
        ('FONTSIZE', (0, 1), (-1, -2), 10),
        ('ALIGN', (1, 1), (1, -1), 'RIGHT'),
        ('LEFTPADDING', (0, 1), (0, -1), 8),
        ('RIGHTPADDING', (1, 1), (1, -1), 8),
        ('TOPPADDING', (0, 1), (-1, -1), 6),
        ('BOTTOMPADDING', (0, 1), (-1, -1), 6),
        
        # NET A PAYER (dernière ligne)
        ('FONTNAME', (0, -1), (-1, -1), 'Helvetica-Bold'),
        ('FONTSIZE', (0, -1), (-1, -1), 12),
        ('BACKGROUND', (0, -1), (-1, -1), colors.lightgrey),
        ('TOPPADDING', (0, -1), (-1, -1), 8),
        ('BOTTOMPADDING', (0, -1), (-1, -1), 8),
        
        # Bordures
        ('GRID', (0, 0), (-1, -1), 1, colors.black),
        ('BOX', (0, 0), (-1, -1), 2, colors.black),
    ]))
    
    # Dessiner le tableau
    table_width, table_height = table.wrap(width, height)
    table.drawOn(c, 30*mm, y - table_height)
    
    y -= (table_height + 10*mm)
    
    # Montant en lettres
    c.setFont("Helvetica", 10)
    c.drawString(30*mm, y, "Arrêté la présente facture à la somme de FCFA :")
    y -= 5*mm
    
    amount_words = amount_to_french_words(invoice_data['total_amount'])
    c.setFont("Helvetica-Bold", 11)
    c.drawString(30*mm, y, amount_words)
    y -= 15*mm
    
    # Signature
    c.setFont("Helvetica", 10)
    c.drawRightString(width - 30*mm, y, "La Directrice")
    
    # Finaliser et sauvegarder
    c.save()
    
    return output_path

def generate_invoice_pdf_from_id(invoice_id):
    """
    Générer un PDF à partir d'un ID de facture
    
    Args:
        invoice_id: ID de la facture dans la base de données
    
    Returns:
        str: Chemin du fichier PDF généré
    """
    from app.database import get_db_connection
    
    conn = get_db_connection()
    cursor = conn.cursor()
    
    # Récupérer la facture
    cursor.execute('''
        SELECT 
            i.*,
            c.name as client_name, c.address as client_address,
            co.name as company_name, co.address as company_address,
            co.phone as company_phone, co.niu as company_niu, co.rc as company_rc
        FROM invoices i
        JOIN clients c ON i.client_id = c.id
        JOIN companies co ON i.company_id = co.id
        WHERE i.id = ?
    ''', (invoice_id,))
    
    invoice = cursor.fetchone()
    
    if not invoice:
        conn.close()
        raise ValueError("Facture non trouvée")
    
    # Récupérer les articles
    cursor.execute('''
        SELECT designation, amount
        FROM invoice_items
        WHERE invoice_id = ?
        ORDER BY item_order
    ''', (invoice_id,))
    
    items = cursor.fetchall()
    conn.close()
    
    # Préparer les données
    invoice_data = dict(invoice)
    invoice_data['items'] = [dict(item) for item in items]
    
    # Générer le PDF
    return generate_invoice_pdf(invoice_data)


