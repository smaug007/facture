# -*- coding: utf-8 -*-
"""
Générateur de numéros de facture
Format: XXX/MM/YYYY
"""

from datetime import datetime
from app.database import get_db_connection

def generate_invoice_number(date, manual_number=None):
    """
    Générer un numéro de facture
    
    Args:
        date: Date de la facture (datetime object)
        manual_number: Numéro manuel (int) si spécifié, sinon auto-incrémente
    
    Returns:
        str: Numéro de facture formaté (ex: "001/11/2025")
    
    Raises:
        ValueError: Si le numéro manuel existe déjà
    """
    month = date.strftime("%m")
    year = date.strftime("%Y")
    
    if manual_number:
        # Numéro manuel spécifié
        try:
            seq = int(manual_number)
            invoice_num = f"{seq:03d}/{month}/{year}"
            
            # Vérifier si existe déjà
            if check_invoice_number_exists(invoice_num):
                raise ValueError(f"Le numéro de facture {invoice_num} existe déjà")
            
            return invoice_num
            
        except (ValueError, TypeError) as e:
            if "existe déjà" in str(e):
                raise
            raise ValueError("Numéro manuel invalide")
    
    # Auto-génération
    conn = get_db_connection()
    cursor = conn.cursor()
    
    # Récupérer le dernier numéro de l'année
    cursor.execute('''
        SELECT invoice_number
        FROM invoices
        WHERE invoice_number LIKE ?
        ORDER BY invoice_number DESC
        LIMIT 1
    ''', (f'%/{year}',))
    
    last_invoice = cursor.fetchone()
    conn.close()
    
    if last_invoice:
        # Extraire le numéro séquentiel
        last_number = last_invoice['invoice_number']
        seq = int(last_number.split('/')[0]) + 1
    else:
        # Première facture de l'année
        seq = 1
    
    return f"{seq:03d}/{month}/{year}"

def check_invoice_number_exists(invoice_number):
    """Vérifier si un numéro de facture existe déjà"""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    cursor.execute('''
        SELECT COUNT(*) as count
        FROM invoices
        WHERE invoice_number = ?
    ''', (invoice_number,))
    
    count = cursor.fetchone()['count']
    conn.close()
    
    return count > 0

def get_last_invoice_number_of_year(year):
    """Récupérer le dernier numéro de facture d'une année"""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    cursor.execute('''
        SELECT invoice_number
        FROM invoices
        WHERE invoice_number LIKE ?
        ORDER BY invoice_number DESC
        LIMIT 1
    ''', (f'%/{year}',))
    
    last_invoice = cursor.fetchone()
    conn.close()
    
    return last_invoice['invoice_number'] if last_invoice else None


