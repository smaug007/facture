# -*- coding: utf-8 -*-
"""
Conversion de montants en lettres (français)
"""

def amount_to_french_words(amount):
    """
    Convertit un montant numérique en lettres (français)
    
    Args:
        amount: Montant numérique (int ou float)
    
    Returns:
        str: Montant en lettres
    
    Exemple:
        1353526 → "Un million trois cent cinquante trois mille cinq cent vingt six"
    """
    try:
        amount = int(float(amount))
    except (ValueError, TypeError):
        return "zéro"
    
    if amount == 0:
        return "zéro"
    
    if amount < 0:
        return "moins " + amount_to_french_words(abs(amount))
    
    # Unités
    units = [
        "", "un", "deux", "trois", "quatre", "cinq", "six", "sept", "huit", "neuf",
        "dix", "onze", "douze", "treize", "quatorze", "quinze", "seize",
        "dix-sept", "dix-huit", "dix-neuf"
    ]
    
    # Dizaines
    tens = [
        "", "", "vingt", "trente", "quarante", "cinquante",
        "soixante", "soixante", "quatre-vingt", "quatre-vingt"
    ]
    
    def convert_below_100(n):
        """Convertir les nombres < 100"""
        if n < 20:
            return units[n]
        elif n < 70:
            unit = n % 10
            ten = n // 10
            if unit == 0:
                return tens[ten]
            elif unit == 1:
                return tens[ten] + " et un"
            else:
                return tens[ten] + "-" + units[unit]
        elif n < 80:
            return "soixante-" + convert_below_100(n - 60)
        elif n < 100:
            if n == 80:
                return "quatre-vingts"
            return "quatre-vingt-" + units[n - 80]
        
        return ""
    
    def convert_below_1000(n):
        """Convertir les nombres < 1000"""
        if n < 100:
            return convert_below_100(n)
        
        hundreds = n // 100
        remainder = n % 100
        
        if hundreds == 1:
            result = "cent"
        else:
            result = units[hundreds] + " cent"
            if remainder == 0:
                result += "s"
        
        if remainder > 0:
            result += " " + convert_below_100(remainder)
        
        return result
    
    def convert_large_number(n):
        """Convertir les grands nombres"""
        if n < 1000:
            return convert_below_1000(n)
        
        # Milliards
        if n >= 1000000000:
            billions = n // 1000000000
            remainder = n % 1000000000
            
            if billions == 1:
                result = "un milliard"
            else:
                result = convert_below_1000(billions) + " milliards"
            
            if remainder > 0:
                result += " " + convert_large_number(remainder)
            
            return result
        
        # Millions
        if n >= 1000000:
            millions = n // 1000000
            remainder = n % 1000000
            
            if millions == 1:
                result = "un million"
            else:
                result = convert_below_1000(millions) + " millions"
            
            if remainder > 0:
                result += " " + convert_large_number(remainder)
            
            return result
        
        # Milliers
        if n >= 1000:
            thousands = n // 1000
            remainder = n % 1000
            
            if thousands == 1:
                result = "mille"
            else:
                result = convert_below_1000(thousands) + " mille"
            
            if remainder > 0:
                result += " " + convert_below_1000(remainder)
            
            return result
        
        return convert_below_1000(n)
    
    result = convert_large_number(amount)
    
    # Capitalize première lettre
    return result[0].upper() + result[1:]


