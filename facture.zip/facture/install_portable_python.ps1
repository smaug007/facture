# Installation de Python Portable (sans installation système)
# Ne nécessite PAS de droits administrateur

Write-Host "=======================================" -ForegroundColor Cyan
Write-Host "  Python Portable - Installation" -ForegroundColor Cyan
Write-Host "=======================================" -ForegroundColor Cyan
Write-Host ""

# Créer le dossier pour Python portable
$pythonDir = "D:\Apprenti\facture\python-portable"
Write-Host "Création du dossier: $pythonDir" -ForegroundColor Yellow

if (-not (Test-Path $pythonDir)) {
    New-Item -ItemType Directory -Path $pythonDir -Force | Out-Null
    Write-Host "✓ Dossier créé" -ForegroundColor Green
} else {
    Write-Host "✓ Dossier existe déjà" -ForegroundColor Green
}

Write-Host ""
Write-Host "Téléchargement de Python 3.12 Portable..." -ForegroundColor Yellow
Write-Host "(Cela peut prendre 2-3 minutes)" -ForegroundColor Gray

# URL de Python embeddable
$pythonUrl = "https://www.python.org/ftp/python/3.12.0/python-3.12.0-embed-amd64.zip"
$zipPath = "$pythonDir\python.zip"

try {
    Invoke-WebRequest -Uri $pythonUrl -OutFile $zipPath -UseBasicParsing
    Write-Host "✓ Téléchargement terminé!" -ForegroundColor Green
} catch {
    Write-Host "✗ Erreur de téléchargement: $_" -ForegroundColor Red
    Write-Host ""
    Write-Host "Solution alternative:" -ForegroundColor Yellow
    Write-Host "1. Allez sur: https://www.python.org/ftp/python/3.12.0/" -ForegroundColor Cyan
    Write-Host "2. Téléchargez: python-3.12.0-embed-amd64.zip" -ForegroundColor Cyan
    Write-Host "3. Extrayez dans: $pythonDir" -ForegroundColor Cyan
    exit 1
}

Write-Host ""
Write-Host "Extraction..." -ForegroundColor Yellow

try {
    Expand-Archive -Path $zipPath -DestinationPath $pythonDir -Force
    Write-Host "✓ Extraction terminée!" -ForegroundColor Green
} catch {
    Write-Host "✗ Erreur d'extraction: $_" -ForegroundColor Red
    exit 1
}

# Nettoyer
Remove-Item $zipPath -Force -ErrorAction SilentlyContinue

Write-Host ""
Write-Host "Configuration de pip..." -ForegroundColor Yellow

# Télécharger get-pip.py
$getPipUrl = "https://bootstrap.pypa.io/get-pip.py"
$getPipPath = "$pythonDir\get-pip.py"

try {
    Invoke-WebRequest -Uri $getPipUrl -OutFile $getPipPath -UseBasicParsing
    
    # Installer pip
    & "$pythonDir\python.exe" $getPipPath
    Write-Host "✓ pip installé!" -ForegroundColor Green
} catch {
    Write-Host "⚠ pip non installé (optionnel)" -ForegroundColor Yellow
}

Write-Host ""
Write-Host "=======================================" -ForegroundColor Green
Write-Host "  Installation terminée!" -ForegroundColor Green
Write-Host "=======================================" -ForegroundColor Green
Write-Host ""

# Créer un script de lancement
$launchScript = @"
@echo off
echo Lancement de AKTIVCO Facturation...
echo.

REM Installer les dépendances si nécessaire
if not exist "venv" (
    echo Installation des dépendances...
    python-portable\python.exe -m pip install -r requirements.txt
)

REM Lancer l'application
python-portable\python.exe main.py

pause
"@

$launchScript | Out-File -FilePath "D:\Apprenti\facture\LANCER_APP.bat" -Encoding ASCII

Write-Host "✓ Script de lancement créé: LANCER_APP.bat" -ForegroundColor Green
Write-Host ""
Write-Host "Comment utiliser Python Portable:" -ForegroundColor Cyan
Write-Host "1. Double-cliquez sur: LANCER_APP.bat" -ForegroundColor White
Write-Host "   OU" -ForegroundColor Gray
Write-Host "2. Dans PowerShell, tapez:" -ForegroundColor White
Write-Host "   python-portable\python.exe main.py" -ForegroundColor Yellow
Write-Host ""
Write-Host "Vérification:" -ForegroundColor Cyan
& "$pythonDir\python.exe" --version

Write-Host ""
Write-Host "Prêt à l'emploi! 🚀" -ForegroundColor Green


