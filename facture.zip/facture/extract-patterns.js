const XLSX = require('xlsx');
const fs = require('fs');

const workbook = XLSX.readFile('FACTURES 2025A OK.xlsx');

const clientInvoices = {};
const invoiceStructures = [];

console.log('=== ANALYZING INVOICES BY CLIENT PATTERNS ===\n');

workbook.SheetNames.forEach((sheetName, index) => {
    const worksheet = workbook.Sheets[sheetName];
    const jsonData = XLSX.utils.sheet_to_json(worksheet, { header: 1, defval: '' });
    
    // Extract key information
    let clientName = '';
    let invoiceNumber = '';
    let date = '';
    let lineItems = [];
    let total = '';
    
    // Find client name (usually in rows 4-6)
    for (let i = 3; i < 7; i++) {
        if (jsonData[i] && jsonData[i].length > 0) {
            const row = jsonData[i].join(' ').trim();
            if (row.includes('CAMEROUN') || row.includes('SARL') || row.includes('SA')) {
                clientName = row;
                break;
            }
        }
    }
    
    // Find date (row 1 usually)
    if (jsonData[0]) {
        const dateRow = jsonData[0].join(' ');
        if (dateRow.includes('Douala')) {
            date = dateRow.replace(/Douala,?\s*le\s*/gi, '').trim();
        }
    }
    
    // Find invoice number (usually has "Facture")
    for (let i = 10; i < 20; i++) {
        if (jsonData[i]) {
            const row = jsonData[i].join(' ');
            if (row.includes('Facture') && row.includes('N°')) {
                invoiceNumber = row.trim();
                break;
            }
        }
    }
    
    // Find line items (after "Désignation" header)
    let headerIndex = -1;
    for (let i = 0; i < jsonData.length; i++) {
        const row = jsonData[i].join(' ').toLowerCase();
        if (row.includes('désignation') || row.includes('designation')) {
            headerIndex = i;
            break;
        }
    }
    
    if (headerIndex > -1) {
        // Extract line items until we hit "NET A PAYER" or empty rows
        for (let i = headerIndex + 2; i < jsonData.length; i++) {
            const row = jsonData[i];
            if (!row || row.length === 0) continue;
            
            const rowText = row.join(' ').toUpperCase();
            if (rowText.includes('NET A PAYER') || rowText.includes('NET À PAYER')) {
                // Found total
                for (let j = 0; j < row.length; j++) {
                    if (typeof row[j] === 'number' && row[j] > 0) {
                        total = row[j];
                        break;
                    }
                    if (typeof row[j] === 'string' && row[j].replace(/\s/g, '').match(/\d/)) {
                        total = row[j];
                        break;
                    }
                }
                break;
            }
            
            // Check if this is a line item (has both description and amount)
            const description = row[0] || '';
            const amount = row[2] || row[1] || '';
            
            if (description && amount && description !== 'DEBOURS') {
                lineItems.push({
                    description: description,
                    amount: amount
                });
            }
        }
    }
    
    // Categorize by client
    const clientKey = clientName || 'UNKNOWN';
    if (!clientInvoices[clientKey]) {
        clientInvoices[clientKey] = [];
    }
    
    clientInvoices[clientKey].push({
        sheetName,
        invoiceNumber,
        date,
        lineItems,
        total
    });
});

// Print summary by client
console.log('=== CLIENT SUMMARY ===\n');
Object.keys(clientInvoices).sort().forEach(client => {
    const invoices = clientInvoices[client];
    console.log(`\n${client}`);
    console.log(`  Total invoices: ${invoices.length}`);
    
    // Collect all unique line items for this client
    const allItems = new Map();
    invoices.forEach(inv => {
        inv.lineItems.forEach(item => {
            const desc = item.description.toString().trim();
            if (desc) {
                const count = allItems.get(desc) || 0;
                allItems.set(desc, count + 1);
            }
        });
    });
    
    console.log(`  Common line items (appearing in multiple invoices):`);
    const sortedItems = Array.from(allItems.entries())
        .sort((a, b) => b[1] - a[1])
        .slice(0, 15);
    
    sortedItems.forEach(([item, count]) => {
        console.log(`    - "${item}" (appears ${count}x)`);
    });
});

// Detailed view of first 3 invoices per client
console.log('\n\n=== DETAILED INVOICE SAMPLES ===\n');
Object.keys(clientInvoices).sort().forEach(client => {
    const invoices = clientInvoices[client];
    console.log(`\n${'='.repeat(70)}`);
    console.log(`CLIENT: ${client}`);
    console.log('='.repeat(70));
    
    // Show first 3 invoices
    invoices.slice(0, 3).forEach((inv, idx) => {
        console.log(`\n--- Invoice ${idx + 1}: ${inv.sheetName} ---`);
        console.log(`Invoice Number: ${inv.invoiceNumber}`);
        console.log(`Date: ${inv.date}`);
        console.log(`Line Items (${inv.lineItems.length}):`);
        inv.lineItems.forEach((item, i) => {
            console.log(`  ${i + 1}. ${item.description} - ${item.amount}`);
        });
        console.log(`Total: ${inv.total}`);
    });
    
    if (invoices.length > 3) {
        console.log(`\n... and ${invoices.length - 3} more invoices for this client`);
    }
});

// Save to file
const output = JSON.stringify(clientInvoices, null, 2);
fs.writeFileSync('client-patterns.json', output);
console.log('\n\n=== Detailed data saved to client-patterns.json ===');


