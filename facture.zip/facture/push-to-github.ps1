# Script pour pousser le projet vers GitHub
# Assurez-vous d'avoir fermé et rouvert PowerShell après l'installation de Git

Write-Host "========================================" -ForegroundColor Cyan
Write-Host "  Push vers GitHub - AKTIVCO Facturation" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""

# Vérifier que Git est disponible
Write-Host "Vérification de Git..." -ForegroundColor Yellow
try {
    $gitVersion = git --version
    Write-Host "Git trouvé: $gitVersion" -ForegroundColor Green
} catch {
    Write-Host "ERREUR: Git n'est pas disponible" -ForegroundColor Red
    Write-Host "Solution: Fermez PowerShell et rouvrez-le" -ForegroundColor Yellow
    exit 1
}

Write-Host ""

# Configurer Git
Write-Host "Configuration de Git..." -ForegroundColor Yellow
git config --global user.name "smaug007"
git config --global user.email "tefack007@gmail.com"
Write-Host "Configuration terminée" -ForegroundColor Green

Write-Host ""

# Initialiser le repo
Write-Host "Initialisation du repository Git..." -ForegroundColor Yellow
git init
Write-Host "Repository initialisé" -ForegroundColor Green

Write-Host ""

# Ajouter tous les fichiers
Write-Host "Ajout des fichiers..." -ForegroundColor Yellow
git add .
Write-Host "Fichiers ajoutés" -ForegroundColor Green

Write-Host ""

# Commit
Write-Host "Création du commit..." -ForegroundColor Yellow
git commit -m "Initial commit - AKTIVCO Facturation MVP Phase 1"
Write-Host "Commit créé" -ForegroundColor Green

Write-Host ""

# Renommer la branche en main
Write-Host "Configuration de la branche principale..." -ForegroundColor Yellow
git branch -M main
Write-Host "Branche configurée" -ForegroundColor Green

Write-Host ""

# Ajouter le remote
Write-Host "Liaison avec GitHub..." -ForegroundColor Yellow
git remote add origin https://github.com/smaug007/facture.git
Write-Host "Remote ajouté" -ForegroundColor Green

Write-Host ""

# Pousser vers GitHub
Write-Host "Push vers GitHub..." -ForegroundColor Yellow
Write-Host "Vous pourriez être invité à entrer vos identifiants GitHub" -ForegroundColor Cyan
git push -u origin main

Write-Host ""
Write-Host "========================================" -ForegroundColor Green
Write-Host "  Push terminé avec succès!" -ForegroundColor Green
Write-Host "========================================" -ForegroundColor Green
Write-Host ""
Write-Host "Votre projet est maintenant sur:" -ForegroundColor Cyan
Write-Host "https://github.com/smaug007/facture" -ForegroundColor White
Write-Host ""


